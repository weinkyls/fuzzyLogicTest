/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getCurrentLim_terminate.c
 *
 * Code generation for function 'getCurrentLim_terminate'
 *
 */

/* Include files */
#include "getCurrentLim_terminate.h"
#include "getCurrentLim_data.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void getCurrentLim_terminate(void)
{
  isInitialized_getCurrentLim = false;
}

/* End of code generation (getCurrentLim_terminate.c) */
