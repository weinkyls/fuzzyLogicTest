/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getCurrentLim_terminate.h
 *
 * Code generation for function 'getCurrentLim_terminate'
 *
 */

#ifndef GETCURRENTLIM_TERMINATE_H
#define GETCURRENTLIM_TERMINATE_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void getCurrentLim_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (getCurrentLim_terminate.h) */
