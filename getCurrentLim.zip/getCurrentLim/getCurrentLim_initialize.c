/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getCurrentLim_initialize.c
 *
 * Code generation for function 'getCurrentLim_initialize'
 *
 */

/* Include files */
#include "getCurrentLim_initialize.h"
#include "getCurrentLim_data.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void getCurrentLim_initialize(void)
{
  rt_InitInfAndNaN();
  isInitialized_getCurrentLim = true;
}

/* End of code generation (getCurrentLim_initialize.c) */
