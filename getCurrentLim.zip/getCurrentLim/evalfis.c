/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * evalfis.c
 *
 * Code generation for function 'evalfis'
 *
 */

/* Include files */
#include "evalfis.h"
#include "evaluateFIS.h"
#include "getCurrentLim_emxutil.h"
#include "getCurrentLim_rtwutil.h"
#include "getCurrentLim_types.h"
#include "rt_nonfinite.h"

/* Function Declarations */
static double b_cast(const emxArray_char_T *t1_mf_type,
                     double t1_mf_origTypeLength,
                     const emxArray_real_T *t1_mf_params,
                     double t1_mf_origParamLength, b_emxArray_struct_T *t2_mf);

static double cast(emxArray_char_T *t0_type, emxArray_real_T *t0_params,
                   double *t0_origParamLength);

/* Function Definitions */
static double b_cast(const emxArray_char_T *t1_mf_type,
                     double t1_mf_origTypeLength,
                     const emxArray_real_T *t1_mf_params,
                     double t1_mf_origParamLength, b_emxArray_struct_T *t2_mf)
{
  c_struct_T *t2_mf_data;
  const double *t1_mf_params_data;
  int i;
  int loop_ub;
  const char *t1_mf_type_data;
  t1_mf_params_data = t1_mf_params->data;
  t1_mf_type_data = t1_mf_type->data;
  i = t2_mf->size[0] * t2_mf->size[1];
  t2_mf->size[0] = 1;
  t2_mf->size[1] = 1;
  emxEnsureCapacity_struct_T(t2_mf, i);
  t2_mf_data = t2_mf->data;
  i = t2_mf_data[0].type->size[0] * t2_mf_data[0].type->size[1];
  t2_mf_data[0].type->size[0] = 1;
  loop_ub = t1_mf_type->size[1];
  t2_mf_data[0].type->size[1] = t1_mf_type->size[1];
  emxEnsureCapacity_char_T(t2_mf_data[0].type, i);
  for (i = 0; i < loop_ub; i++) {
    t2_mf_data[0].type->data[i] = t1_mf_type_data[i];
  }
  t2_mf_data[0].origTypeLength = t1_mf_origTypeLength;
  i = t2_mf_data[0].params->size[0] * t2_mf_data[0].params->size[1];
  t2_mf_data[0].params->size[0] = 1;
  loop_ub = t1_mf_params->size[1];
  t2_mf_data[0].params->size[1] = t1_mf_params->size[1];
  emxEnsureCapacity_real_T(t2_mf_data[0].params, i);
  for (i = 0; i < loop_ub; i++) {
    t2_mf_data[0].params->data[i] = t1_mf_params_data[i];
  }
  t2_mf_data[0].origParamLength = t1_mf_origParamLength;
  return 0.0;
}

static double cast(emxArray_char_T *t0_type, emxArray_real_T *t0_params,
                   double *t0_origParamLength)
{
  double t0_origTypeLength;
  double *t0_params_data;
  int i;
  char *t0_type_data;
  i = t0_type->size[0] * t0_type->size[1];
  t0_type->size[0] = 1;
  t0_type->size[1] = 1;
  emxEnsureCapacity_char_T(t0_type, i);
  t0_type_data = t0_type->data;
  t0_type_data[0] = '\x00';
  i = t0_params->size[0] * t0_params->size[1];
  t0_params->size[0] = 1;
  t0_params->size[1] = 1;
  emxEnsureCapacity_real_T(t0_params, i);
  t0_params_data = t0_params->data;
  t0_params_data[0] = 0.0;
  t0_origTypeLength = 0.0;
  *t0_origParamLength = 0.0;
  return t0_origTypeLength;
}

double evalfis(const char arg1_andMethod[4], const char arg1_orMethod[6],
               const char arg1_defuzzMethod[6], const struct1_T arg1_input[3],
               const double arg1_output_range[2],
               const struct4_T arg1_output_mf[5], double arg1_output_origNumMF,
               const struct5_T arg1_rule[8], const double arg2[3])
{
  b_emxArray_struct_T *fis_outputMF_mf;
  b_struct_T fish_inputMF[3];
  b_struct_T b_varStruct;
  c_struct_T mfStruct_tmp;
  c_struct_T *fis_outputMF_mf_data;
  d_struct_T fis_inputMF[3];
  d_struct_T varStruct;
  emxArray_struct_T *fish_outputMF_mf;
  struct_T b_mfStruct;
  struct_T mfStruct;
  struct_T *fish_outputMF_mf_data;
  double fis_antecedent[24];
  double fis_connection[8];
  double fis_consequent[8];
  double fis_weight[8];
  double d;
  double maxMFParamLength;
  double maxMFTypeLength;
  double varargout_1;
  int fish_numCumInputMFs[3];
  int fish_numInputMFs[3];
  int fis_inputMF_idx_1;
  int i;
  int loop_ub_tmp;
  int loop_ub_tmp_tmp;
  int mfID;
  int varID;
  unsigned char fish_defuzzMethod[6];
  unsigned char fish_orMethod[6];
  unsigned char fish_andMethod[4];
  emxInitStruct_struct_T(&mfStruct_tmp);
  mfStruct_tmp.origTypeLength = cast(mfStruct_tmp.type, mfStruct_tmp.params,
                                     &mfStruct_tmp.origParamLength);
  emxInitStruct_struct_T3(&varStruct);
  varStruct.origNumMF =
      b_cast(mfStruct_tmp.type, mfStruct_tmp.origTypeLength,
             mfStruct_tmp.params, mfStruct_tmp.origParamLength, varStruct.mf);
  emxInitMatrix_struct_T1(fis_inputMF);
  varargout_1 = 0.0;
  maxMFTypeLength = 0.0;
  maxMFParamLength = 0.0;
  for (varID = 0; varID < 3; varID++) {
    emxCopyStruct_struct_T(&fis_inputMF[varID], &varStruct);
    d = arg1_input[varID].origNumMF;
    if (varargout_1 < d) {
      varargout_1 = d;
    }
    i = (int)d;
    for (mfID = 0; mfID < i; mfID++) {
      d = arg1_input[varID].mf[mfID].origTypeLength;
      if (maxMFTypeLength < d) {
        maxMFTypeLength = d;
      }
      d = arg1_input[varID].mf[mfID].origParamLength;
      if (maxMFParamLength < d) {
        maxMFParamLength = d;
      }
    }
  }
  emxFreeStruct_struct_T3(&varStruct);
  loop_ub_tmp_tmp = (int)varargout_1;
  for (varID = 0; varID < 3; varID++) {
    fis_inputMF[varID].origNumMF = arg1_input[varID].origNumMF;
    i = fis_inputMF[varID].mf->size[0] * fis_inputMF[varID].mf->size[1];
    fis_inputMF[varID].mf->size[0] = 1;
    fis_inputMF[varID].mf->size[1] = (int)varargout_1;
    emxEnsureCapacity_struct_T(fis_inputMF[varID].mf, i);
    for (i = 0; i < loop_ub_tmp_tmp; i++) {
      emxCopyStruct_struct_T1(&fis_inputMF[varID].mf->data[i], &mfStruct_tmp);
    }
    for (mfID = 0; mfID < loop_ub_tmp_tmp; mfID++) {
      i = fis_inputMF[varID].mf->data[mfID].type->size[0] *
          fis_inputMF[varID].mf->data[mfID].type->size[1];
      fis_inputMF[varID].mf->data[mfID].type->size[0] = 1;
      loop_ub_tmp = (int)maxMFTypeLength;
      fis_inputMF[varID].mf->data[mfID].type->size[1] = (int)maxMFTypeLength;
      emxEnsureCapacity_char_T(fis_inputMF[varID].mf->data[mfID].type, i);
      for (i = 0; i < loop_ub_tmp; i++) {
        fis_inputMF[varID].mf->data[mfID].type->data[i] = '\x00';
      }
      i = fis_inputMF[varID].mf->data[mfID].params->size[0] *
          fis_inputMF[varID].mf->data[mfID].params->size[1];
      fis_inputMF[varID].mf->data[mfID].params->size[0] = 1;
      loop_ub_tmp = (int)maxMFParamLength;
      fis_inputMF[varID].mf->data[mfID].params->size[1] = (int)maxMFParamLength;
      emxEnsureCapacity_real_T(fis_inputMF[varID].mf->data[mfID].params, i);
      for (i = 0; i < loop_ub_tmp; i++) {
        fis_inputMF[varID].mf->data[mfID].params->data[i] = 0.0;
      }
      fis_inputMF[varID].mf->data[mfID].origTypeLength = 0.0;
      fis_inputMF[varID].mf->data[mfID].origParamLength = 0.0;
      if ((double)mfID + 1.0 <= fis_inputMF[varID].origNumMF) {
        fis_inputMF_idx_1 = fis_inputMF[varID].mf->data[mfID].type->size[1];
        i = fis_inputMF[varID].mf->data[mfID].type->size[0] *
            fis_inputMF[varID].mf->data[mfID].type->size[1];
        fis_inputMF[varID].mf->data[mfID].type->size[0] = 1;
        fis_inputMF[varID].mf->data[mfID].type->size[1] = fis_inputMF_idx_1;
        emxEnsureCapacity_char_T(fis_inputMF[varID].mf->data[mfID].type, i);
        for (i = 0; i < fis_inputMF_idx_1; i++) {
          fis_inputMF[varID].mf->data[mfID].type->data[i] =
              arg1_input[varID].mf[mfID].type[i];
        }
        fis_inputMF[varID].mf->data[mfID].origTypeLength =
            arg1_input[varID].mf[mfID].origTypeLength;
        fis_inputMF_idx_1 = fis_inputMF[varID].mf->data[mfID].params->size[1];
        i = fis_inputMF[varID].mf->data[mfID].params->size[0] *
            fis_inputMF[varID].mf->data[mfID].params->size[1];
        fis_inputMF[varID].mf->data[mfID].params->size[0] = 1;
        fis_inputMF[varID].mf->data[mfID].params->size[1] = fis_inputMF_idx_1;
        emxEnsureCapacity_real_T(fis_inputMF[varID].mf->data[mfID].params, i);
        for (i = 0; i < fis_inputMF_idx_1; i++) {
          fis_inputMF[varID].mf->data[mfID].params->data[i] =
              arg1_input[varID].mf[mfID].params[i];
        }
        fis_inputMF[varID].mf->data[mfID].origParamLength =
            arg1_input[varID].mf[mfID].origParamLength;
      }
    }
  }
  varargout_1 = 0.0;
  maxMFTypeLength = 0.0;
  maxMFParamLength = 0.0;
  if (arg1_output_origNumMF > 0.0) {
    varargout_1 = arg1_output_origNumMF;
  }
  i = (int)arg1_output_origNumMF;
  for (mfID = 0; mfID < i; mfID++) {
    d = arg1_output_mf[mfID].origTypeLength;
    if (maxMFTypeLength < d) {
      maxMFTypeLength = d;
    }
    d = arg1_output_mf[mfID].origParamLength;
    if (maxMFParamLength < d) {
      maxMFParamLength = d;
    }
  }
  emxInit_struct_T1(&fis_outputMF_mf);
  i = fis_outputMF_mf->size[0] * fis_outputMF_mf->size[1];
  fis_outputMF_mf->size[0] = 1;
  loop_ub_tmp = (int)varargout_1;
  fis_outputMF_mf->size[1] = (int)varargout_1;
  emxEnsureCapacity_struct_T(fis_outputMF_mf, i);
  fis_outputMF_mf_data = fis_outputMF_mf->data;
  for (i = 0; i < loop_ub_tmp; i++) {
    emxCopyStruct_struct_T1(&fis_outputMF_mf_data[i], &mfStruct_tmp);
  }
  emxFreeStruct_struct_T(&mfStruct_tmp);
  for (mfID = 0; mfID < loop_ub_tmp; mfID++) {
    i = fis_outputMF_mf_data[mfID].type->size[0] *
        fis_outputMF_mf_data[mfID].type->size[1];
    fis_outputMF_mf_data[mfID].type->size[0] = 1;
    loop_ub_tmp_tmp = (int)maxMFTypeLength;
    fis_outputMF_mf_data[mfID].type->size[1] = (int)maxMFTypeLength;
    emxEnsureCapacity_char_T(fis_outputMF_mf_data[mfID].type, i);
    for (i = 0; i < loop_ub_tmp_tmp; i++) {
      fis_outputMF_mf_data[mfID].type->data[i] = '\x00';
    }
    i = fis_outputMF_mf_data[mfID].params->size[0] *
        fis_outputMF_mf_data[mfID].params->size[1];
    fis_outputMF_mf_data[mfID].params->size[0] = 1;
    loop_ub_tmp_tmp = (int)maxMFParamLength;
    fis_outputMF_mf_data[mfID].params->size[1] = (int)maxMFParamLength;
    emxEnsureCapacity_real_T(fis_outputMF_mf_data[mfID].params, i);
    for (i = 0; i < loop_ub_tmp_tmp; i++) {
      fis_outputMF_mf_data[mfID].params->data[i] = 0.0;
    }
    fis_outputMF_mf_data[mfID].origTypeLength = 0.0;
    fis_outputMF_mf_data[mfID].origParamLength = 0.0;
    if ((double)mfID + 1.0 <= arg1_output_origNumMF) {
      fis_inputMF_idx_1 = fis_outputMF_mf_data[mfID].type->size[1];
      i = fis_outputMF_mf_data[mfID].type->size[0] *
          fis_outputMF_mf_data[mfID].type->size[1];
      fis_outputMF_mf_data[mfID].type->size[0] = 1;
      fis_outputMF_mf_data[mfID].type->size[1] = fis_inputMF_idx_1;
      emxEnsureCapacity_char_T(fis_outputMF_mf_data[mfID].type, i);
      for (i = 0; i < fis_inputMF_idx_1; i++) {
        fis_outputMF_mf_data[mfID].type->data[i] = arg1_output_mf[mfID].type[i];
      }
      fis_outputMF_mf_data[mfID].origTypeLength =
          arg1_output_mf[mfID].origTypeLength;
      fis_inputMF_idx_1 = fis_outputMF_mf_data[mfID].params->size[1];
      i = fis_outputMF_mf_data[mfID].params->size[0] *
          fis_outputMF_mf_data[mfID].params->size[1];
      fis_outputMF_mf_data[mfID].params->size[0] = 1;
      fis_outputMF_mf_data[mfID].params->size[1] = fis_inputMF_idx_1;
      emxEnsureCapacity_real_T(fis_outputMF_mf_data[mfID].params, i);
      for (i = 0; i < fis_inputMF_idx_1; i++) {
        fis_outputMF_mf_data[mfID].params->data[i] =
            arg1_output_mf[mfID].params;
      }
      fis_outputMF_mf_data[mfID].origParamLength =
          arg1_output_mf[mfID].origParamLength;
    }
  }
  for (loop_ub_tmp_tmp = 0; loop_ub_tmp_tmp < 8; loop_ub_tmp_tmp++) {
    fis_antecedent[loop_ub_tmp_tmp] = arg1_rule[loop_ub_tmp_tmp].antecedent[0];
    fis_antecedent[loop_ub_tmp_tmp + 8] =
        arg1_rule[loop_ub_tmp_tmp].antecedent[1];
    fis_antecedent[loop_ub_tmp_tmp + 16] =
        arg1_rule[loop_ub_tmp_tmp].antecedent[2];
    fis_consequent[loop_ub_tmp_tmp] = arg1_rule[loop_ub_tmp_tmp].consequent;
    fis_connection[loop_ub_tmp_tmp] = arg1_rule[loop_ub_tmp_tmp].connection;
    fis_weight[loop_ub_tmp_tmp] = arg1_rule[loop_ub_tmp_tmp].weight;
  }
  maxMFTypeLength = arg1_input[0].origNumMF + arg1_input[1].origNumMF;
  fish_andMethod[0] = (unsigned char)arg1_andMethod[0];
  fish_andMethod[1] = (unsigned char)arg1_andMethod[1];
  fish_andMethod[2] = (unsigned char)arg1_andMethod[2];
  fish_andMethod[3] = (unsigned char)arg1_andMethod[3];
  for (i = 0; i < 6; i++) {
    fish_orMethod[i] = (unsigned char)arg1_orMethod[i];
    fish_defuzzMethod[i] = (unsigned char)arg1_defuzzMethod[i];
  }
  emxInitStruct_struct_T1(&mfStruct);
  i = mfStruct.type->size[0] * mfStruct.type->size[1];
  mfStruct.type->size[0] = 1;
  fis_inputMF_idx_1 = fis_inputMF[0].mf->data[0].type->size[1];
  mfStruct.type->size[1] = fis_inputMF[0].mf->data[0].type->size[1];
  emxEnsureCapacity_char_T(mfStruct.type, i);
  for (i = 0; i < fis_inputMF_idx_1; i++) {
    mfStruct.type->data[i] = '\x00';
  }
  mfStruct.origTypeLength = 0;
  i = mfStruct.params->size[0] * mfStruct.params->size[1];
  mfStruct.params->size[0] = 1;
  fis_inputMF_idx_1 = fis_inputMF[0].mf->data[0].params->size[1];
  mfStruct.params->size[1] = fis_inputMF[0].mf->data[0].params->size[1];
  emxEnsureCapacity_real_T(mfStruct.params, i);
  for (i = 0; i < fis_inputMF_idx_1; i++) {
    mfStruct.params->data[i] = 0.0;
  }
  mfStruct.origParamLength = 0;
  emxInitStruct_struct_T2(&b_varStruct);
  i = b_varStruct.mf->size[0] * b_varStruct.mf->size[1];
  b_varStruct.mf->size[0] = 1;
  fis_inputMF_idx_1 = fis_inputMF[0].mf->size[1];
  b_varStruct.mf->size[1] = fis_inputMF[0].mf->size[1];
  emxEnsureCapacity_struct_T1(b_varStruct.mf, i);
  for (i = 0; i < fis_inputMF_idx_1; i++) {
    emxCopyStruct_struct_T2(&b_varStruct.mf->data[i], &mfStruct);
  }
  emxFreeStruct_struct_T1(&mfStruct);
  b_varStruct.origNumMF = 0;
  emxInitMatrix_struct_T(fish_inputMF);
  for (varID = 0; varID < 3; varID++) {
    emxCopyStruct_struct_T3(&fish_inputMF[varID], &b_varStruct);
    d = rt_roundd_snf(fis_inputMF[varID].origNumMF);
    if (d < 2.147483648E+9) {
      if (d >= -2.147483648E+9) {
        i = (int)d;
      } else {
        i = MIN_int32_T;
      }
    } else if (d >= 2.147483648E+9) {
      i = MAX_int32_T;
    } else {
      i = 0;
    }
    fish_inputMF[varID].origNumMF = i;
    for (mfID = 0; mfID < fis_inputMF_idx_1; mfID++) {
      i = fish_inputMF[varID].mf->data[mfID].type->size[0] *
          fish_inputMF[varID].mf->data[mfID].type->size[1];
      fish_inputMF[varID].mf->data[mfID].type->size[0] = 1;
      loop_ub_tmp_tmp = fis_inputMF[varID].mf->data[mfID].type->size[1];
      fish_inputMF[varID].mf->data[mfID].type->size[1] = loop_ub_tmp_tmp;
      emxEnsureCapacity_char_T(fish_inputMF[varID].mf->data[mfID].type, i);
      for (i = 0; i < loop_ub_tmp_tmp; i++) {
        fish_inputMF[varID].mf->data[mfID].type->data[i] =
            fis_inputMF[varID].mf->data[mfID].type->data[i];
      }
      i = fish_inputMF[varID].mf->data[mfID].params->size[0] *
          fish_inputMF[varID].mf->data[mfID].params->size[1];
      fish_inputMF[varID].mf->data[mfID].params->size[0] = 1;
      loop_ub_tmp_tmp = fis_inputMF[varID].mf->data[mfID].params->size[1];
      fish_inputMF[varID].mf->data[mfID].params->size[1] = loop_ub_tmp_tmp;
      emxEnsureCapacity_real_T(fish_inputMF[varID].mf->data[mfID].params, i);
      for (i = 0; i < loop_ub_tmp_tmp; i++) {
        fish_inputMF[varID].mf->data[mfID].params->data[i] =
            fis_inputMF[varID].mf->data[mfID].params->data[i];
      }
      d = rt_roundd_snf(fis_inputMF[varID].mf->data[mfID].origTypeLength);
      if (d < 2.147483648E+9) {
        if (d >= -2.147483648E+9) {
          i = (int)d;
        } else {
          i = MIN_int32_T;
        }
      } else if (d >= 2.147483648E+9) {
        i = MAX_int32_T;
      } else {
        i = 0;
      }
      fish_inputMF[varID].mf->data[mfID].origTypeLength = i;
      d = rt_roundd_snf(fis_inputMF[varID].mf->data[mfID].origParamLength);
      if (d < 2.147483648E+9) {
        if (d >= -2.147483648E+9) {
          i = (int)d;
        } else {
          i = MIN_int32_T;
        }
      } else if (d >= 2.147483648E+9) {
        i = MAX_int32_T;
      } else {
        i = 0;
      }
      fish_inputMF[varID].mf->data[mfID].origParamLength = i;
    }
  }
  emxFreeStruct_struct_T2(&b_varStruct);
  emxFreeMatrix_struct_T1(fis_inputMF);
  emxInitStruct_struct_T1(&b_mfStruct);
  i = b_mfStruct.type->size[0] * b_mfStruct.type->size[1];
  b_mfStruct.type->size[0] = 1;
  fis_inputMF_idx_1 = fis_outputMF_mf_data[0].type->size[1];
  b_mfStruct.type->size[1] = fis_outputMF_mf_data[0].type->size[1];
  emxEnsureCapacity_char_T(b_mfStruct.type, i);
  for (i = 0; i < fis_inputMF_idx_1; i++) {
    b_mfStruct.type->data[i] = '\x00';
  }
  b_mfStruct.origTypeLength = 0;
  i = b_mfStruct.params->size[0] * b_mfStruct.params->size[1];
  b_mfStruct.params->size[0] = 1;
  fis_inputMF_idx_1 = fis_outputMF_mf_data[0].params->size[1];
  b_mfStruct.params->size[1] = fis_outputMF_mf_data[0].params->size[1];
  emxEnsureCapacity_real_T(b_mfStruct.params, i);
  for (i = 0; i < fis_inputMF_idx_1; i++) {
    b_mfStruct.params->data[i] = 0.0;
  }
  b_mfStruct.origParamLength = 0;
  emxInit_struct_T(&fish_outputMF_mf);
  i = fish_outputMF_mf->size[0] * fish_outputMF_mf->size[1];
  fish_outputMF_mf->size[0] = 1;
  fish_outputMF_mf->size[1] = (int)varargout_1;
  emxEnsureCapacity_struct_T1(fish_outputMF_mf, i);
  fish_outputMF_mf_data = fish_outputMF_mf->data;
  for (mfID = 0; mfID < loop_ub_tmp; mfID++) {
    emxCopyStruct_struct_T2(&fish_outputMF_mf_data[mfID], &b_mfStruct);
    i = fish_outputMF_mf_data[mfID].type->size[0] *
        fish_outputMF_mf_data[mfID].type->size[1];
    fish_outputMF_mf_data[mfID].type->size[0] = 1;
    loop_ub_tmp_tmp = fis_outputMF_mf_data[mfID].type->size[1];
    fish_outputMF_mf_data[mfID].type->size[1] = loop_ub_tmp_tmp;
    emxEnsureCapacity_char_T(fish_outputMF_mf_data[mfID].type, i);
    for (i = 0; i < loop_ub_tmp_tmp; i++) {
      fish_outputMF_mf_data[mfID].type->data[i] =
          fis_outputMF_mf_data[mfID].type->data[i];
    }
    i = fish_outputMF_mf_data[mfID].params->size[0] *
        fish_outputMF_mf_data[mfID].params->size[1];
    fish_outputMF_mf_data[mfID].params->size[0] = 1;
    loop_ub_tmp_tmp = fis_outputMF_mf_data[mfID].params->size[1];
    fish_outputMF_mf_data[mfID].params->size[1] = loop_ub_tmp_tmp;
    emxEnsureCapacity_real_T(fish_outputMF_mf_data[mfID].params, i);
    for (i = 0; i < loop_ub_tmp_tmp; i++) {
      fish_outputMF_mf_data[mfID].params->data[i] =
          fis_outputMF_mf_data[mfID].params->data[i];
    }
    d = rt_roundd_snf(fis_outputMF_mf_data[mfID].origTypeLength);
    if (d < 2.147483648E+9) {
      if (d >= -2.147483648E+9) {
        i = (int)d;
      } else {
        i = MIN_int32_T;
      }
    } else if (d >= 2.147483648E+9) {
      i = MAX_int32_T;
    } else {
      i = 0;
    }
    fish_outputMF_mf_data[mfID].origTypeLength = i;
    d = rt_roundd_snf(fis_outputMF_mf_data[mfID].origParamLength);
    if (d < 2.147483648E+9) {
      if (d >= -2.147483648E+9) {
        i = (int)d;
      } else {
        i = MIN_int32_T;
      }
    } else if (d >= 2.147483648E+9) {
      i = MAX_int32_T;
    } else {
      i = 0;
    }
    fish_outputMF_mf_data[mfID].origParamLength = i;
  }
  emxFreeStruct_struct_T1(&b_mfStruct);
  emxFree_struct_T1(&fis_outputMF_mf);
  d = rt_roundd_snf(arg1_input[0].origNumMF);
  if (d < 2.147483648E+9) {
    if (d >= -2.147483648E+9) {
      i = (int)d;
    } else {
      i = MIN_int32_T;
    }
  } else if (d >= 2.147483648E+9) {
    i = MAX_int32_T;
  } else {
    i = 0;
  }
  fish_numInputMFs[0] = i;
  d = rt_roundd_snf(arg1_input[0].origNumMF - arg1_input[0].origNumMF);
  if (d < 2.147483648E+9) {
    if (d >= -2.147483648E+9) {
      i = (int)d;
    } else {
      i = MIN_int32_T;
    }
  } else if (d >= 2.147483648E+9) {
    i = MAX_int32_T;
  } else {
    i = 0;
  }
  fish_numCumInputMFs[0] = i;
  d = rt_roundd_snf(arg1_input[1].origNumMF);
  if (d < 2.147483648E+9) {
    if (d >= -2.147483648E+9) {
      i = (int)d;
    } else {
      i = MIN_int32_T;
    }
  } else if (d >= 2.147483648E+9) {
    i = MAX_int32_T;
  } else {
    i = 0;
  }
  fish_numInputMFs[1] = i;
  d = rt_roundd_snf(maxMFTypeLength - arg1_input[1].origNumMF);
  if (d < 2.147483648E+9) {
    if (d >= -2.147483648E+9) {
      i = (int)d;
    } else {
      i = MIN_int32_T;
    }
  } else if (d >= 2.147483648E+9) {
    i = MAX_int32_T;
  } else {
    i = 0;
  }
  fish_numCumInputMFs[1] = i;
  d = rt_roundd_snf(arg1_input[2].origNumMF);
  if (d < 2.147483648E+9) {
    if (d >= -2.147483648E+9) {
      i = (int)d;
    } else {
      i = MIN_int32_T;
    }
  } else if (d >= 2.147483648E+9) {
    i = MAX_int32_T;
  } else {
    i = 0;
  }
  fish_numInputMFs[2] = i;
  d = rt_roundd_snf((maxMFTypeLength + arg1_input[2].origNumMF) -
                    arg1_input[2].origNumMF);
  if (d < 2.147483648E+9) {
    if (d >= -2.147483648E+9) {
      i = (int)d;
    } else {
      i = MIN_int32_T;
    }
  } else if (d >= 2.147483648E+9) {
    i = MAX_int32_T;
  } else {
    i = 0;
  }
  fish_numCumInputMFs[2] = i;
  d = rt_roundd_snf(arg1_output_origNumMF);
  if (d < 2.147483648E+9) {
    if (d >= -2.147483648E+9) {
      loop_ub_tmp_tmp = (int)d;
      i = loop_ub_tmp_tmp;
    } else {
      loop_ub_tmp_tmp = MIN_int32_T;
      i = MIN_int32_T;
    }
  } else if (d >= 2.147483648E+9) {
    loop_ub_tmp_tmp = MAX_int32_T;
    i = MAX_int32_T;
  } else {
    loop_ub_tmp_tmp = 0;
    i = 0;
  }
  d = rt_roundd_snf(arg1_output_origNumMF - arg1_output_origNumMF);
  if (d < 2.147483648E+9) {
    if (d >= -2.147483648E+9) {
      fis_inputMF_idx_1 = (int)d;
    } else {
      fis_inputMF_idx_1 = MIN_int32_T;
    }
  } else if (d >= 2.147483648E+9) {
    fis_inputMF_idx_1 = MAX_int32_T;
  } else {
    fis_inputMF_idx_1 = 0;
  }
  varargout_1 = evaluateFIS(
      arg2, fish_andMethod, fish_orMethod, fish_defuzzMethod, arg1_output_range,
      fish_inputMF, fish_outputMF_mf, loop_ub_tmp_tmp, fis_antecedent,
      fis_consequent, fis_connection, fis_weight, fish_numInputMFs,
      fish_numCumInputMFs, i, fis_inputMF_idx_1);
  emxFree_struct_T(&fish_outputMF_mf);
  emxFreeMatrix_struct_T(fish_inputMF);
  return varargout_1;
}

/* End of code generation (evalfis.c) */
