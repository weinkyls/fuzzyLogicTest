/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * fuzzifyInputs.h
 *
 * Code generation for function 'fuzzifyInputs'
 *
 */

#ifndef FUZZIFYINPUTS_H
#define FUZZIFYINPUTS_H

/* Include files */
#include "getCurrentLim_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void fuzzifyInputs(const double inputs[3], const double fis_antecedent[24],
                   const double fis_connection[8], const int fis_numInputMFs[3],
                   const int fis_numCumInputMFs[3],
                   const cell_wrap_0 varargin_1[3], emxArray_real_T *varargin_2,
                   double fuzzifiedInputs[24]);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (fuzzifyInputs.h) */
