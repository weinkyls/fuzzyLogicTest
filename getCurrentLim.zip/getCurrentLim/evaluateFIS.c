/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * evaluateFIS.c
 *
 * Code generation for function 'evaluateFIS'
 *
 */

/* Include files */
#include "evaluateFIS.h"
#include "fuzzifyInputs.h"
#include "getCurrentLim_emxutil.h"
#include "getCurrentLim_rtwutil.h"
#include "getCurrentLim_types.h"
#include "isequal.h"
#include "rt_nonfinite.h"
#include <string.h>

/* Function Definitions */
double evaluateFIS(const double inputs[3], const unsigned char fis_andMethod[4],
                   const unsigned char fis_orMethod[6],
                   const unsigned char fis_defuzzMethod[6],
                   const double fis_outputRange[2],
                   const b_struct_T fis_inputMF[3],
                   const emxArray_struct_T *fis_outputMF_mf,
                   int fis_outputMF_origNumMF, const double fis_antecedent[24],
                   const double fis_consequent[8],
                   const double fis_connection[8], const double fis_weight[8],
                   const int fis_numInputMFs[3],
                   const int fis_numCumInputMFs[3], int fis_numOutputMFs,
                   int fis_numCumOutputMFs)
{
  static const unsigned char uv3[8] = {99U,  111U, 110U, 115U,
                                       116U, 97U,  110U, 116U};
  static const unsigned char uv[6] = {119U, 116U, 97U, 118U, 101U, 114U};
  static const unsigned char uv1[6] = {112U, 114U, 111U, 98U, 111U, 114U};
  static const unsigned char uv2[4] = {112U, 114U, 111U, 100U};
  cell_wrap_0 inVarMF[3];
  e_struct_T b_expl_temp;
  e_struct_T c_expl_temp;
  e_struct_T d_expl_temp;
  e_struct_T expl_temp;
  emxArray_real_T *outputMFCache;
  emxArray_real_T *r;
  const struct_T *fis_outputMF_mf_data;
  double irr[24];
  double consequentOutputs_tmp[8];
  double w[8];
  double sw;
  double unnamed_idx_0;
  double unnamed_idx_1;
  double unnamed_idx_2;
  double y;
  double *outputMFCache_data;
  int i;
  int j;
  int k;
  int loop_ub;
  int mfID;
  boolean_T exitg1;
  boolean_T p;
  fis_outputMF_mf_data = fis_outputMF_mf->data;
  p = true;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 6)) {
    if (fis_defuzzMethod[k] != uv[k]) {
      p = false;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (p) {
    emxInitMatrix_cell_wrap_0(inVarMF);
    i = inVarMF[2].f1->size[0] * inVarMF[2].f1->size[1];
    inVarMF[2].f1->size[0] = 1;
    mfID = fis_inputMF[0].origNumMF;
    inVarMF[2].f1->size[1] = fis_inputMF[0].origNumMF;
    emxEnsureCapacity_struct_T2(inVarMF[2].f1, i);
    emxInitStruct_struct_T4(&expl_temp);
    for (j = 0; j < mfID; j++) {
      k = fis_inputMF[0].mf->data[j].origTypeLength;
      if (k < 1) {
        loop_ub = 0;
      } else {
        loop_ub = k;
      }
      k = fis_inputMF[0].mf->data[j].origParamLength;
      if (k < 1) {
        k = 0;
      }
      i = expl_temp.type->size[0] * expl_temp.type->size[1];
      expl_temp.type->size[0] = 1;
      expl_temp.type->size[1] = loop_ub;
      emxEnsureCapacity_char_T(expl_temp.type, i);
      for (i = 0; i < loop_ub; i++) {
        expl_temp.type->data[i] = fis_inputMF[0].mf->data[j].type->data[i];
      }
      i = expl_temp.params->size[0] * expl_temp.params->size[1];
      expl_temp.params->size[0] = 1;
      expl_temp.params->size[1] = k;
      emxEnsureCapacity_real_T(expl_temp.params, i);
      for (i = 0; i < k; i++) {
        expl_temp.params->data[i] = fis_inputMF[0].mf->data[j].params->data[i];
      }
      emxCopyStruct_struct_T4(&inVarMF[2].f1->data[j], &expl_temp);
    }
    emxFreeStruct_struct_T4(&expl_temp);
    i = inVarMF[0].f1->size[0] * inVarMF[0].f1->size[1];
    inVarMF[0].f1->size[0] = 1;
    emxEnsureCapacity_struct_T2(inVarMF[0].f1, i);
    loop_ub = inVarMF[2].f1->size[1];
    i = inVarMF[0].f1->size[0] * inVarMF[0].f1->size[1];
    inVarMF[0].f1->size[1] = inVarMF[2].f1->size[1];
    emxEnsureCapacity_struct_T2(inVarMF[0].f1, i);
    for (i = 0; i < loop_ub; i++) {
      emxCopyStruct_struct_T4(&inVarMF[0].f1->data[i], &inVarMF[2].f1->data[i]);
    }
    i = inVarMF[2].f1->size[0] * inVarMF[2].f1->size[1];
    inVarMF[2].f1->size[0] = 1;
    mfID = fis_inputMF[1].origNumMF;
    inVarMF[2].f1->size[1] = fis_inputMF[1].origNumMF;
    emxEnsureCapacity_struct_T2(inVarMF[2].f1, i);
    emxInitStruct_struct_T4(&b_expl_temp);
    for (j = 0; j < mfID; j++) {
      k = fis_inputMF[1].mf->data[j].origTypeLength;
      if (k < 1) {
        loop_ub = 0;
      } else {
        loop_ub = k;
      }
      k = fis_inputMF[1].mf->data[j].origParamLength;
      if (k < 1) {
        k = 0;
      }
      i = b_expl_temp.type->size[0] * b_expl_temp.type->size[1];
      b_expl_temp.type->size[0] = 1;
      b_expl_temp.type->size[1] = loop_ub;
      emxEnsureCapacity_char_T(b_expl_temp.type, i);
      for (i = 0; i < loop_ub; i++) {
        b_expl_temp.type->data[i] = fis_inputMF[1].mf->data[j].type->data[i];
      }
      i = b_expl_temp.params->size[0] * b_expl_temp.params->size[1];
      b_expl_temp.params->size[0] = 1;
      b_expl_temp.params->size[1] = k;
      emxEnsureCapacity_real_T(b_expl_temp.params, i);
      for (i = 0; i < k; i++) {
        b_expl_temp.params->data[i] =
            fis_inputMF[1].mf->data[j].params->data[i];
      }
      emxCopyStruct_struct_T4(&inVarMF[2].f1->data[j], &b_expl_temp);
    }
    emxFreeStruct_struct_T4(&b_expl_temp);
    i = inVarMF[1].f1->size[0] * inVarMF[1].f1->size[1];
    inVarMF[1].f1->size[0] = 1;
    emxEnsureCapacity_struct_T2(inVarMF[1].f1, i);
    loop_ub = inVarMF[2].f1->size[1];
    i = inVarMF[1].f1->size[0] * inVarMF[1].f1->size[1];
    inVarMF[1].f1->size[1] = inVarMF[2].f1->size[1];
    emxEnsureCapacity_struct_T2(inVarMF[1].f1, i);
    for (i = 0; i < loop_ub; i++) {
      emxCopyStruct_struct_T4(&inVarMF[1].f1->data[i], &inVarMF[2].f1->data[i]);
    }
    i = inVarMF[2].f1->size[0] * inVarMF[2].f1->size[1];
    inVarMF[2].f1->size[0] = 1;
    mfID = fis_inputMF[2].origNumMF;
    inVarMF[2].f1->size[1] = fis_inputMF[2].origNumMF;
    emxEnsureCapacity_struct_T2(inVarMF[2].f1, i);
    emxInitStruct_struct_T4(&c_expl_temp);
    for (j = 0; j < mfID; j++) {
      k = fis_inputMF[2].mf->data[j].origTypeLength;
      if (k < 1) {
        loop_ub = 0;
      } else {
        loop_ub = k;
      }
      k = fis_inputMF[2].mf->data[j].origParamLength;
      if (k < 1) {
        k = 0;
      }
      i = c_expl_temp.type->size[0] * c_expl_temp.type->size[1];
      c_expl_temp.type->size[0] = 1;
      c_expl_temp.type->size[1] = loop_ub;
      emxEnsureCapacity_char_T(c_expl_temp.type, i);
      for (i = 0; i < loop_ub; i++) {
        c_expl_temp.type->data[i] = fis_inputMF[2].mf->data[j].type->data[i];
      }
      i = c_expl_temp.params->size[0] * c_expl_temp.params->size[1];
      c_expl_temp.params->size[0] = 1;
      c_expl_temp.params->size[1] = k;
      emxEnsureCapacity_real_T(c_expl_temp.params, i);
      for (i = 0; i < k; i++) {
        c_expl_temp.params->data[i] =
            fis_inputMF[2].mf->data[j].params->data[i];
      }
      emxCopyStruct_struct_T4(&inVarMF[2].f1->data[j], &c_expl_temp);
    }
    emxFreeStruct_struct_T4(&c_expl_temp);
    emxInit_real_T(&r, 2);
    i = r->size[0] * r->size[1];
    r->size[0] = 1;
    k = (int)(((double)fis_numInputMFs[0] + (double)fis_numInputMFs[1]) +
              (double)fis_numInputMFs[2]);
    r->size[1] =
        (int)(((double)fis_numInputMFs[0] + (double)fis_numInputMFs[1]) +
              (double)fis_numInputMFs[2]);
    emxEnsureCapacity_real_T(r, i);
    outputMFCache_data = r->data;
    for (i = 0; i < k; i++) {
      outputMFCache_data[i] = 0.0;
    }
    fuzzifyInputs(inputs, fis_antecedent, fis_connection, fis_numInputMFs,
                  fis_numCumInputMFs, inVarMF, r, irr);
    emxFree_real_T(&r);
    sw = 0.0;
    for (loop_ub = 0; loop_ub < 8; loop_ub++) {
      unnamed_idx_0 = irr[loop_ub];
      unnamed_idx_1 = irr[loop_ub + 8];
      unnamed_idx_2 = irr[loop_ub + 16];
      if (fis_connection[loop_ub] == 1.0) {
        y = -1.0;
        p = true;
        k = 0;
        exitg1 = false;
        while ((!exitg1) && (k < 4)) {
          if (fis_andMethod[k] != uv2[k]) {
            p = false;
            exitg1 = true;
          } else {
            k++;
          }
        }
        if (p) {
          y = unnamed_idx_0 * unnamed_idx_1 * unnamed_idx_2;
        } else {
          exit(0);
        }
      } else {
        y = -1.0;
        p = true;
        k = 0;
        exitg1 = false;
        while ((!exitg1) && (k < 6)) {
          if (fis_orMethod[k] != uv1[k]) {
            p = false;
            exitg1 = true;
          } else {
            k++;
          }
        }
        if (p) {
          y = (unnamed_idx_0 + unnamed_idx_1) - unnamed_idx_0 * unnamed_idx_1;
          y = (y + unnamed_idx_2) - y * unnamed_idx_2;
        } else {
          exit(0);
        }
      }
      y *= fis_weight[loop_ub];
      w[loop_ub] = y;
      sw += y;
    }
    memset(&consequentOutputs_tmp[0], 0, 8U * sizeof(double));
    emxInit_real_T(&outputMFCache, 1);
    i = outputMFCache->size[0];
    outputMFCache->size[0] = fis_numOutputMFs;
    emxEnsureCapacity_real_T(outputMFCache, i);
    outputMFCache_data = outputMFCache->data;
    for (i = 0; i < fis_numOutputMFs; i++) {
      outputMFCache_data[i] = 0.0;
    }
    i = inVarMF[2].f1->size[0] * inVarMF[2].f1->size[1];
    inVarMF[2].f1->size[0] = 1;
    inVarMF[2].f1->size[1] = fis_outputMF_origNumMF;
    emxEnsureCapacity_struct_T2(inVarMF[2].f1, i);
    emxInitStruct_struct_T4(&d_expl_temp);
    for (j = 0; j < fis_outputMF_origNumMF; j++) {
      k = fis_outputMF_mf_data[j].origTypeLength;
      if (k < 1) {
        loop_ub = 0;
      } else {
        loop_ub = k;
      }
      k = fis_outputMF_mf_data[j].origParamLength;
      if (k < 1) {
        k = 0;
      }
      i = d_expl_temp.type->size[0] * d_expl_temp.type->size[1];
      d_expl_temp.type->size[0] = 1;
      d_expl_temp.type->size[1] = loop_ub;
      emxEnsureCapacity_char_T(d_expl_temp.type, i);
      for (i = 0; i < loop_ub; i++) {
        d_expl_temp.type->data[i] = fis_outputMF_mf_data[j].type->data[i];
      }
      i = d_expl_temp.params->size[0] * d_expl_temp.params->size[1];
      d_expl_temp.params->size[0] = 1;
      d_expl_temp.params->size[1] = k;
      emxEnsureCapacity_real_T(d_expl_temp.params, i);
      for (i = 0; i < k; i++) {
        d_expl_temp.params->data[i] = fis_outputMF_mf_data[j].params->data[i];
      }
      emxCopyStruct_struct_T4(&inVarMF[2].f1->data[j], &d_expl_temp);
    }
    emxFreeStruct_struct_T4(&d_expl_temp);
    for (mfID = 0; mfID < fis_numOutputMFs; mfID++) {
      if (e_isequal(inVarMF[2].f1->data[mfID].type, uv3)) {
        if ((fis_numCumOutputMFs < 0) &&
            (mfID + 1 < MIN_int32_T - fis_numCumOutputMFs)) {
          k = MIN_int32_T;
        } else if ((fis_numCumOutputMFs > 0) &&
                   (mfID + 1 > MAX_int32_T - fis_numCumOutputMFs)) {
          k = MAX_int32_T;
        } else {
          k = (fis_numCumOutputMFs + mfID) + 1;
        }
        outputMFCache_data[k - 1] = inVarMF[2].f1->data[mfID].params->data[0];
      } else {
        if ((fis_numCumOutputMFs < 0) &&
            (mfID + 1 < MIN_int32_T - fis_numCumOutputMFs)) {
          k = MIN_int32_T;
        } else if ((fis_numCumOutputMFs > 0) &&
                   (mfID + 1 > MAX_int32_T - fis_numCumOutputMFs)) {
          k = MAX_int32_T;
        } else {
          k = (fis_numCumOutputMFs + mfID) + 1;
        }
        outputMFCache_data[k - 1] =
            ((inputs[0] * inVarMF[2].f1->data[mfID].params->data[0] +
              inputs[1] * inVarMF[2].f1->data[mfID].params->data[1]) +
             inputs[2] * inVarMF[2].f1->data[mfID].params->data[2]) +
            inVarMF[2].f1->data[mfID].params->data[3];
      }
    }
    emxFreeMatrix_cell_wrap_0(inVarMF);
    for (loop_ub = 0; loop_ub < 8; loop_ub++) {
      unnamed_idx_0 = rt_roundd_snf(fis_consequent[loop_ub]);
      if (unnamed_idx_0 < 2.147483648E+9) {
        if (unnamed_idx_0 >= -2.147483648E+9) {
          k = (int)unnamed_idx_0;
        } else {
          k = MIN_int32_T;
        }
      } else if (unnamed_idx_0 >= 2.147483648E+9) {
        k = MAX_int32_T;
      } else {
        k = 0;
      }
      if (k != 0) {
        if ((fis_numCumOutputMFs < 0) &&
            (k < MIN_int32_T - fis_numCumOutputMFs)) {
          k = MIN_int32_T;
        } else if ((fis_numCumOutputMFs > 0) &&
                   (k > MAX_int32_T - fis_numCumOutputMFs)) {
          k = MAX_int32_T;
        } else {
          k += fis_numCumOutputMFs;
        }
        consequentOutputs_tmp[loop_ub] = outputMFCache_data[k - 1] * w[loop_ub];
      }
    }
    emxFree_real_T(&outputMFCache);
    unnamed_idx_0 = consequentOutputs_tmp[0];
    for (k = 0; k < 7; k++) {
      unnamed_idx_0 += consequentOutputs_tmp[k + 1];
    }
    if (sw == 0.0) {
      y = (fis_outputRange[0] + fis_outputRange[1]) / 2.0;
    } else {
      y = unnamed_idx_0 * (1.0 / sw);
    }
  } else {
    y = 0.0;
    exit(0);
  }
  return y;
}

/* End of code generation (evaluateFIS.c) */
