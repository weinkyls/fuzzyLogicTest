/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getCurrentLim_data.c
 *
 * Code generation for function 'getCurrentLim_data'
 *
 */

/* Include files */
#include "getCurrentLim_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_getCurrentLim = false;

/* End of code generation (getCurrentLim_data.c) */
