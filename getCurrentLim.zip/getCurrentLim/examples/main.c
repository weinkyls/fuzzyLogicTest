/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * main.c
 *
 * Code generation for function 'main'
 *
 */

/*************************************************************************/
/* This automatically generated example C main file shows how to call    */
/* entry-point functions that MATLAB Coder generated. You must customize */
/* this file for your application. Do not modify this file directly.     */
/* Instead, make a copy of this file, modify it, and integrate it into   */
/* your development environment.                                         */
/*                                                                       */
/* This file initializes entry-point function arguments to a default     */
/* size and value before calling the entry-point functions. It does      */
/* not store or use any values returned from the entry-point functions.  */
/* If necessary, it does pre-allocate memory for returned values.        */
/* You can use this file as a starting point for a main function that    */
/* you can deploy in your application.                                   */
/*                                                                       */
/* After you copy the file, and before you deploy it, you must make the  */
/* following changes:                                                    */
/* * For variable-size function arguments, change the example sizes to   */
/* the sizes that your application requires.                             */
/* * Change the example values of function arguments to the values that  */
/* your application requires.                                            */
/* * If the entry-point functions return values, store these values or   */
/* otherwise use them as required by your application.                   */
/*                                                                       */
/*************************************************************************/

/* Include files */
#include "main.h"
#include "getCurrentLim.h"
#include "getCurrentLim_terminate.h"
#include "getCurrentLim_types.h"
#include "rt_nonfinite.h"

/* Function Declarations */
static void argInit_1x10_char_T(char result[10]);

static void argInit_1x14_char_T(char result[14]);

static void argInit_1x17_char_T(char result[17]);

static void argInit_1x2_real_T(double result[2]);

static void argInit_1x2_struct2_T(struct2_T result[2]);

static void argInit_1x3_char_T(char result[3]);

static void argInit_1x3_real_T(double result[3]);

static void argInit_1x3_struct1_T(struct1_T result[3]);

static void argInit_1x4_char_T(char result[4]);

static void argInit_1x4_real_T(double result[4]);

static void argInit_1x5_struct4_T(struct4_T result[5]);

static void argInit_1x6_char_T(char result[6]);

static void argInit_1x7_char_T(char result[7]);

static void argInit_1x8_char_T(char result[8]);

static void argInit_1x8_struct5_T(struct5_T result[8]);

static void argInit_1x9_char_T(char result[9]);

static char argInit_char_T(void);

static double argInit_real_T(void);

static void argInit_struct0_T(struct0_T *result);

static void argInit_struct1_T(struct1_T *result);

static void argInit_struct2_T(struct2_T *result);

static void argInit_struct3_T(struct3_T *result);

static struct4_T argInit_struct4_T(void);

static struct5_T argInit_struct5_T(void);

/* Function Definitions */
static void argInit_1x10_char_T(char result[10])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 10; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_char_T();
  }
}

static void argInit_1x14_char_T(char result[14])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 14; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_char_T();
  }
}

static void argInit_1x17_char_T(char result[17])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 17; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_char_T();
  }
}

static void argInit_1x2_real_T(double result[2])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 2; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_real_T();
  }
}

static void argInit_1x2_struct2_T(struct2_T result[2])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 2; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    argInit_struct2_T(&result[idx1]);
  }
}

static void argInit_1x3_char_T(char result[3])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 3; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_char_T();
  }
}

static void argInit_1x3_real_T(double result[3])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 3; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_real_T();
  }
}

static void argInit_1x3_struct1_T(struct1_T result[3])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 3; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    argInit_struct1_T(&result[idx1]);
  }
}

static void argInit_1x4_char_T(char result[4])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 4; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_char_T();
  }
}

static void argInit_1x4_real_T(double result[4])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 4; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_real_T();
  }
}

static void argInit_1x5_struct4_T(struct4_T result[5])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 5; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_struct4_T();
  }
}

static void argInit_1x6_char_T(char result[6])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 6; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_char_T();
  }
}

static void argInit_1x7_char_T(char result[7])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 7; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_char_T();
  }
}

static void argInit_1x8_char_T(char result[8])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 8; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_char_T();
  }
}

static void argInit_1x8_struct5_T(struct5_T result[8])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 8; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_struct5_T();
  }
}

static void argInit_1x9_char_T(char result[9])
{
  int idx1;
  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < 9; idx1++) {
    /* Set the value of the array element.
Change this value to the value that the application requires. */
    result[idx1] = argInit_char_T();
  }
}

static char argInit_char_T(void)
{
  return '?';
}

static double argInit_real_T(void)
{
  return 0.0;
}

static void argInit_struct0_T(struct0_T *result)
{
  int i;
  /* Set the value of each structure field.
Change this value to the value that the application requires. */
  argInit_1x6_char_T(result->type);
  argInit_1x4_char_T(result->andMethod);
  argInit_1x9_char_T(result->name);
  argInit_1x3_char_T(result->aggMethod);
  argInit_1x3_struct1_T(result->input);
  argInit_struct3_T(&result->output);
  argInit_1x8_struct5_T(result->rule);
  for (i = 0; i < 6; i++) {
    result->orMethod[i] = result->type[i];
    result->defuzzMethod[i] = result->type[i];
  }
  result->impMethod[0] = result->andMethod[0];
  result->impMethod[1] = result->andMethod[1];
  result->impMethod[2] = result->andMethod[2];
  result->impMethod[3] = result->andMethod[3];
}

static void argInit_struct1_T(struct1_T *result)
{
  double result_tmp;
  /* Set the value of each structure field.
Change this value to the value that the application requires. */
  result_tmp = argInit_real_T();
  argInit_1x17_char_T(result->name);
  result->origNameLength = result_tmp;
  argInit_1x2_real_T(result->range);
  argInit_1x2_struct2_T(result->mf);
  result->origNumMF = result_tmp;
}

static void argInit_struct2_T(struct2_T *result)
{
  double result_tmp;
  /* Set the value of each structure field.
Change this value to the value that the application requires. */
  result_tmp = argInit_real_T();
  argInit_1x10_char_T(result->name);
  result->origNameLength = result_tmp;
  argInit_1x6_char_T(result->type);
  result->origTypeLength = result_tmp;
  argInit_1x4_real_T(result->params);
  result->origParamLength = result_tmp;
}

static void argInit_struct3_T(struct3_T *result)
{
  double result_tmp;
  /* Set the value of each structure field.
Change this value to the value that the application requires. */
  result_tmp = argInit_real_T();
  argInit_1x7_char_T(result->name);
  result->origNameLength = result_tmp;
  argInit_1x2_real_T(result->range);
  argInit_1x5_struct4_T(result->mf);
  result->origNumMF = result_tmp;
}

static struct4_T argInit_struct4_T(void)
{
  struct4_T result;
  double result_tmp;
  /* Set the value of each structure field.
Change this value to the value that the application requires. */
  result_tmp = argInit_real_T();
  argInit_1x14_char_T(result.name);
  result.origNameLength = result_tmp;
  argInit_1x8_char_T(result.type);
  result.origTypeLength = result_tmp;
  result.params = result_tmp;
  result.origParamLength = result_tmp;
  return result;
}

static struct5_T argInit_struct5_T(void)
{
  struct5_T result;
  double result_tmp;
  /* Set the value of each structure field.
Change this value to the value that the application requires. */
  result_tmp = argInit_real_T();
  argInit_1x3_real_T(result.antecedent);
  result.consequent = result_tmp;
  result.weight = result_tmp;
  result.connection = result_tmp;
  return result;
}

int main(int argc, char **argv)
{
  (void)argc;
  (void)argv;
  /* The initialize function is being called automatically from your entry-point
   * function. So, a call to initialize is not included here. */
  /* Invoke the entry-point functions.
You can call entry-point functions multiple times. */
  main_getCurrentLim();
  /* Terminate the application.
You do not need to do this more than one time. */
  getCurrentLim_terminate();
  return 0;
}

void main_getCurrentLim(void)
{
  struct0_T r;
  double temp_cell_tmp;
  /* Initialize function 'getCurrentLim' input arguments. */
  /* Initialize function input argument 'fisData'. */
  temp_cell_tmp = argInit_real_T();
  /* Call the entry-point 'getCurrentLim'. */
  argInit_struct0_T(&r);
  temp_cell_tmp =
      getCurrentLim(&r, temp_cell_tmp, temp_cell_tmp, temp_cell_tmp);
}

/* End of code generation (main.c) */
