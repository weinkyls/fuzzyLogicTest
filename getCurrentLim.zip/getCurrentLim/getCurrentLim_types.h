/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getCurrentLim_types.h
 *
 * Code generation for function 'getCurrentLim'
 *
 */

#ifndef GETCURRENTLIM_TYPES_H
#define GETCURRENTLIM_TYPES_H

/* Include files */
#include "rtwtypes.h"

/* Type Definitions */
#ifndef typedef_struct2_T
#define typedef_struct2_T
typedef struct {
  char name[10];
  double origNameLength;
  char type[6];
  double origTypeLength;
  double params[4];
  double origParamLength;
} struct2_T;
#endif /* typedef_struct2_T */

#ifndef typedef_struct1_T
#define typedef_struct1_T
typedef struct {
  char name[17];
  double origNameLength;
  double range[2];
  struct2_T mf[2];
  double origNumMF;
} struct1_T;
#endif /* typedef_struct1_T */

#ifndef typedef_struct4_T
#define typedef_struct4_T
typedef struct {
  char name[14];
  double origNameLength;
  char type[8];
  double origTypeLength;
  double params;
  double origParamLength;
} struct4_T;
#endif /* typedef_struct4_T */

#ifndef typedef_struct5_T
#define typedef_struct5_T
typedef struct {
  double antecedent[3];
  double consequent;
  double weight;
  double connection;
} struct5_T;
#endif /* typedef_struct5_T */

#ifndef typedef_struct3_T
#define typedef_struct3_T
typedef struct {
  char name[7];
  double origNameLength;
  double range[2];
  struct4_T mf[5];
  double origNumMF;
} struct3_T;
#endif /* typedef_struct3_T */

#ifndef typedef_struct0_T
#define typedef_struct0_T
typedef struct {
  char name[9];
  char type[6];
  char andMethod[4];
  char orMethod[6];
  char defuzzMethod[6];
  char impMethod[4];
  char aggMethod[3];
  struct1_T input[3];
  struct3_T output;
  struct5_T rule[8];
} struct0_T;
#endif /* typedef_struct0_T */

#ifndef struct_emxArray_char_T
#define struct_emxArray_char_T
struct emxArray_char_T {
  char *data;
  int *size;
  int allocatedSize;
  int numDimensions;
  boolean_T canFreeData;
};
#endif /* struct_emxArray_char_T */
#ifndef typedef_emxArray_char_T
#define typedef_emxArray_char_T
typedef struct emxArray_char_T emxArray_char_T;
#endif /* typedef_emxArray_char_T */

#ifndef struct_emxArray_real_T
#define struct_emxArray_real_T
struct emxArray_real_T {
  double *data;
  int *size;
  int allocatedSize;
  int numDimensions;
  boolean_T canFreeData;
};
#endif /* struct_emxArray_real_T */
#ifndef typedef_emxArray_real_T
#define typedef_emxArray_real_T
typedef struct emxArray_real_T emxArray_real_T;
#endif /* typedef_emxArray_real_T */

#ifndef typedef_struct_T
#define typedef_struct_T
typedef struct {
  emxArray_char_T *type;
  int origTypeLength;
  emxArray_real_T *params;
  int origParamLength;
} struct_T;
#endif /* typedef_struct_T */

#ifndef typedef_emxArray_struct_T
#define typedef_emxArray_struct_T
typedef struct {
  struct_T *data;
  int *size;
  int allocatedSize;
  int numDimensions;
  boolean_T canFreeData;
} emxArray_struct_T;
#endif /* typedef_emxArray_struct_T */

#ifndef typedef_b_struct_T
#define typedef_b_struct_T
typedef struct {
  emxArray_struct_T *mf;
  int origNumMF;
} b_struct_T;
#endif /* typedef_b_struct_T */

#ifndef typedef_c_struct_T
#define typedef_c_struct_T
typedef struct {
  emxArray_char_T *type;
  double origTypeLength;
  emxArray_real_T *params;
  double origParamLength;
} c_struct_T;
#endif /* typedef_c_struct_T */

#ifndef typedef_b_emxArray_struct_T
#define typedef_b_emxArray_struct_T
typedef struct {
  c_struct_T *data;
  int *size;
  int allocatedSize;
  int numDimensions;
  boolean_T canFreeData;
} b_emxArray_struct_T;
#endif /* typedef_b_emxArray_struct_T */

#ifndef typedef_d_struct_T
#define typedef_d_struct_T
typedef struct {
  b_emxArray_struct_T *mf;
  double origNumMF;
} d_struct_T;
#endif /* typedef_d_struct_T */

#ifndef typedef_e_struct_T
#define typedef_e_struct_T
typedef struct {
  emxArray_char_T *type;
  emxArray_real_T *params;
} e_struct_T;
#endif /* typedef_e_struct_T */

#ifndef typedef_c_emxArray_struct_T
#define typedef_c_emxArray_struct_T
typedef struct {
  e_struct_T *data;
  int *size;
  int allocatedSize;
  int numDimensions;
  boolean_T canFreeData;
} c_emxArray_struct_T;
#endif /* typedef_c_emxArray_struct_T */

#ifndef typedef_cell_wrap_0
#define typedef_cell_wrap_0
typedef struct {
  c_emxArray_struct_T *f1;
} cell_wrap_0;
#endif /* typedef_cell_wrap_0 */

#endif
/* End of code generation (getCurrentLim_types.h) */
