/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getCurrentLim_initialize.h
 *
 * Code generation for function 'getCurrentLim_initialize'
 *
 */

#ifndef GETCURRENTLIM_INITIALIZE_H
#define GETCURRENTLIM_INITIALIZE_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void getCurrentLim_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (getCurrentLim_initialize.h) */
