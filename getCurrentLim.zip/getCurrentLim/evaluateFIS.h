/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * evaluateFIS.h
 *
 * Code generation for function 'evaluateFIS'
 *
 */

#ifndef EVALUATEFIS_H
#define EVALUATEFIS_H

/* Include files */
#include "getCurrentLim_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
double evaluateFIS(const double inputs[3], const unsigned char fis_andMethod[4],
                   const unsigned char fis_orMethod[6],
                   const unsigned char fis_defuzzMethod[6],
                   const double fis_outputRange[2],
                   const b_struct_T fis_inputMF[3],
                   const emxArray_struct_T *fis_outputMF_mf,
                   int fis_outputMF_origNumMF, const double fis_antecedent[24],
                   const double fis_consequent[8],
                   const double fis_connection[8], const double fis_weight[8],
                   const int fis_numInputMFs[3],
                   const int fis_numCumInputMFs[3], int fis_numOutputMFs,
                   int fis_numCumOutputMFs);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (evaluateFIS.h) */
