/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * fuzzifyInputs.c
 *
 * Code generation for function 'fuzzifyInputs'
 *
 */

/* Include files */
#include "fuzzifyInputs.h"
#include "getCurrentLim_rtwutil.h"
#include "getCurrentLim_types.h"
#include "isequal.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
void fuzzifyInputs(const double inputs[3], const double fis_antecedent[24],
                   const double fis_connection[8], const int fis_numInputMFs[3],
                   const int fis_numCumInputMFs[3],
                   const cell_wrap_0 varargin_1[3], emxArray_real_T *varargin_2,
                   double fuzzifiedInputs[24])
{
  static const unsigned char uv9[8] = {103U, 97U, 117U, 115U,
                                       115U, 50U, 109U, 102U};
  static const unsigned char uv2[7] = {103U, 97U, 117U, 115U, 115U, 109U, 102U};
  static const unsigned char uv3[7] = {103U, 98U, 101U, 108U, 108U, 109U, 102U};
  static const unsigned char uv1[6] = {116U, 114U, 97U, 112U, 109U, 102U};
  static const unsigned char uv10[6] = {100U, 115U, 105U, 103U, 109U, 102U};
  static const unsigned char uv11[6] = {112U, 115U, 105U, 103U, 109U, 102U};
  static const unsigned char uv7[6] = {108U, 105U, 110U, 115U, 109U, 102U};
  static const unsigned char uv8[6] = {108U, 105U, 110U, 122U, 109U, 102U};
  static const unsigned char uv[5] = {116U, 114U, 105U, 109U, 102U};
  static const unsigned char uv4[5] = {115U, 105U, 103U, 109U, 102U};
  static const unsigned char uv12[4] = {112U, 105U, 109U, 102U};
  static const unsigned char uv5[3] = {115U, 109U, 102U};
  static const unsigned char uv6[3] = {122U, 109U, 102U};
  double b_value;
  double d;
  double d1;
  double d2;
  double y;
  double *varargin_2_data;
  int inputID;
  int mfID;
  int numMFs;
  int q0;
  int qY;
  boolean_T b;
  boolean_T c1Index;
  boolean_T c2Index;
  boolean_T exitg1;
  varargin_2_data = varargin_2->data;
  for (inputID = 0; inputID < 3; inputID++) {
    numMFs = fis_numInputMFs[inputID];
    for (mfID = 0; mfID < numMFs; mfID++) {
      q0 = fis_numCumInputMFs[inputID];
      b = ((q0 < 0) && (mfID + 1 < MIN_int32_T - q0));
      if (b) {
        qY = MIN_int32_T;
      } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
        qY = MAX_int32_T;
      } else {
        qY = (q0 + mfID) + 1;
      }
      varargin_2_data[qY - 1] = -1.0;
      if (isequal(varargin_1[inputID].f1->data[mfID].type, uv)) {
        if (b) {
          qY = MIN_int32_T;
        } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
          qY = MAX_int32_T;
        } else {
          qY = (q0 + mfID) + 1;
        }
        varargin_2_data[qY - 1] = 0.0;
        d = varargin_1[inputID].f1->data[mfID].params->data[0];
        d1 = varargin_1[inputID].f1->data[mfID].params->data[1];
        if (d != d1) {
          d2 = inputs[inputID];
          if ((d < d2) && (d2 < d1)) {
            if (b) {
              qY = MIN_int32_T;
            } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
              qY = MAX_int32_T;
            } else {
              qY = (q0 + mfID) + 1;
            }
            varargin_2_data[qY - 1] = (d2 - d) * (1.0 / (d1 - d));
          }
        }
        d = varargin_1[inputID].f1->data[mfID].params->data[2];
        if (d1 != d) {
          d2 = inputs[inputID];
          if ((d1 < d2) && (d2 < d)) {
            if (b) {
              qY = MIN_int32_T;
            } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
              qY = MAX_int32_T;
            } else {
              qY = (q0 + mfID) + 1;
            }
            varargin_2_data[qY - 1] = (d - d2) * (1.0 / (d - d1));
          }
        }
        if (inputs[inputID] == d1) {
          if (b) {
            qY = MIN_int32_T;
          } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
            qY = MAX_int32_T;
          } else {
            qY = (q0 + mfID) + 1;
          }
          varargin_2_data[qY - 1] = 1.0;
        }
      } else if (b_isequal(varargin_1[inputID].f1->data[mfID].type, uv1)) {
        b_value = 0.0;
        y = 0.0;
        d = varargin_1[inputID].f1->data[mfID].params->data[1];
        d1 = inputs[inputID];
        if (d1 >= d) {
          b_value = 1.0;
        }
        d2 = varargin_1[inputID].f1->data[mfID].params->data[0];
        if (d1 < d2) {
          b_value = 0.0;
        }
        if ((d2 <= d1) && (d1 < d) && (d2 != d)) {
          b_value = (d1 - d2) * (1.0 / (d - d2));
        }
        d = varargin_1[inputID].f1->data[mfID].params->data[2];
        if (d1 <= d) {
          y = 1.0;
        }
        d2 = varargin_1[inputID].f1->data[mfID].params->data[3];
        if (d1 > d2) {
          y = 0.0;
        }
        if ((d < d1) && (d1 <= d2) && (d != d2)) {
          y = (d2 - d1) * (1.0 / (d2 - d));
        }
        if ((b_value <= y) || rtIsNaN(y)) {
          if (b) {
            qY = MIN_int32_T;
          } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
            qY = MAX_int32_T;
          } else {
            qY = (q0 + mfID) + 1;
          }
          varargin_2_data[qY - 1] = b_value;
        } else {
          if (b) {
            qY = MIN_int32_T;
          } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
            qY = MAX_int32_T;
          } else {
            qY = (q0 + mfID) + 1;
          }
          varargin_2_data[qY - 1] = y;
        }
      } else if (c_isequal(varargin_1[inputID].f1->data[mfID].type, uv2)) {
        y = inputs[inputID] -
            varargin_1[inputID].f1->data[mfID].params->data[1];
        d = varargin_1[inputID].f1->data[mfID].params->data[0];
        if (b) {
          qY = MIN_int32_T;
        } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
          qY = MAX_int32_T;
        } else {
          qY = (q0 + mfID) + 1;
        }
        varargin_2_data[qY - 1] = exp(-(y * y) / (2.0 * (d * d)));
      } else if (c_isequal(varargin_1[inputID].f1->data[mfID].type, uv3)) {
        y = 0.0;
        b_value = (inputs[inputID] -
                   varargin_1[inputID].f1->data[mfID].params->data[2]) *
                  (1.0 / varargin_1[inputID].f1->data[mfID].params->data[0]);
        b_value *= b_value;
        if ((b_value <= 0.0) &&
            (varargin_1[inputID].f1->data[mfID].params->data[1] == 0.0)) {
          y = 0.5;
        } else if ((!(b_value <= 0.0)) ||
                   (!(varargin_1[inputID].f1->data[mfID].params->data[1] <
                      0.0))) {
          d = varargin_1[inputID].f1->data[mfID].params->data[1];
          if (rtIsNaN(b_value) || rtIsNaN(d)) {
            b_value = rtNaN;
          } else {
            d1 = fabs(b_value);
            d2 = fabs(d);
            if (rtIsInf(d)) {
              if (d1 == 1.0) {
                b_value = 1.0;
              } else if (d1 > 1.0) {
                if (d > 0.0) {
                  b_value = rtInf;
                } else {
                  b_value = 0.0;
                }
              } else if (d > 0.0) {
                b_value = 0.0;
              } else {
                b_value = rtInf;
              }
            } else if (d2 == 0.0) {
              b_value = 1.0;
            } else if (d2 == 1.0) {
              if (!(d > 0.0)) {
                b_value = 1.0 / b_value;
              }
            } else if (d == 2.0) {
              b_value *= b_value;
            } else if ((d == 0.5) && (b_value >= 0.0)) {
              b_value = sqrt(b_value);
            } else if ((b_value < 0.0) && (d > floor(d))) {
              b_value = rtNaN;
            } else {
              b_value = pow(b_value, d);
            }
          }
          y = 1.0 / (b_value + 1.0);
        }
        if (b) {
          qY = MIN_int32_T;
        } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
          qY = MAX_int32_T;
        } else {
          qY = (q0 + mfID) + 1;
        }
        varargin_2_data[qY - 1] = y;
      } else if (isequal(varargin_1[inputID].f1->data[mfID].type, uv4)) {
        if (b) {
          qY = MIN_int32_T;
        } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
          qY = MAX_int32_T;
        } else {
          qY = (q0 + mfID) + 1;
        }
        varargin_2_data[qY - 1] =
            1.0 / (exp(-varargin_1[inputID].f1->data[mfID].params->data[0] *
                       (inputs[inputID] -
                        varargin_1[inputID].f1->data[mfID].params->data[1])) +
                   1.0);
      } else if (d_isequal(varargin_1[inputID].f1->data[mfID].type, uv5)) {
        d = varargin_1[inputID].f1->data[mfID].params->data[0];
        d1 = varargin_1[inputID].f1->data[mfID].params->data[1];
        if (d >= d1) {
          if (b) {
            qY = MIN_int32_T;
          } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
            qY = MAX_int32_T;
          } else {
            qY = (q0 + mfID) + 1;
          }
          varargin_2_data[qY - 1] = (inputs[inputID] >= (d + d1) / 2.0);
        } else {
          if (b) {
            qY = MIN_int32_T;
          } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
            qY = MAX_int32_T;
          } else {
            qY = (q0 + mfID) + 1;
          }
          varargin_2_data[qY - 1] = 0.0;
          d2 = inputs[inputID];
          if ((d < d2) && (d2 <= (d + d1) / 2.0)) {
            b_value = (d2 - d) * (1.0 / (d1 - d));
            if (b) {
              qY = MIN_int32_T;
            } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
              qY = MAX_int32_T;
            } else {
              qY = (q0 + mfID) + 1;
            }
            varargin_2_data[qY - 1] = 2.0 * b_value * b_value;
          }
          if (((d + d1) / 2.0 < d2) && (d2 <= d1)) {
            b_value = (d1 - d2) * (1.0 / (d1 - d));
            if (b) {
              qY = MIN_int32_T;
            } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
              qY = MAX_int32_T;
            } else {
              qY = (q0 + mfID) + 1;
            }
            varargin_2_data[qY - 1] = 1.0 - 2.0 * b_value * b_value;
          }
          if (d1 <= d2) {
            if (b) {
              qY = MIN_int32_T;
            } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
              qY = MAX_int32_T;
            } else {
              qY = (q0 + mfID) + 1;
            }
            varargin_2_data[qY - 1] = 1.0;
          }
        }
      } else if (d_isequal(varargin_1[inputID].f1->data[mfID].type, uv6)) {
        d = varargin_1[inputID].f1->data[mfID].params->data[0];
        d1 = varargin_1[inputID].f1->data[mfID].params->data[1];
        if (d >= d1) {
          if (b) {
            qY = MIN_int32_T;
          } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
            qY = MAX_int32_T;
          } else {
            qY = (q0 + mfID) + 1;
          }
          varargin_2_data[qY - 1] = (inputs[inputID] <= (d + d1) / 2.0);
        } else {
          if (b) {
            qY = MIN_int32_T;
          } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
            qY = MAX_int32_T;
          } else {
            qY = (q0 + mfID) + 1;
          }
          varargin_2_data[qY - 1] = 0.0;
          d2 = inputs[inputID];
          if (d2 <= d) {
            if (b) {
              qY = MIN_int32_T;
            } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
              qY = MAX_int32_T;
            } else {
              qY = (q0 + mfID) + 1;
            }
            varargin_2_data[qY - 1] = 1.0;
          }
          if ((d < d2) && (d2 <= (d + d1) / 2.0)) {
            b_value = (d2 - d) * (1.0 / (d - d1));
            if (b) {
              qY = MIN_int32_T;
            } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
              qY = MAX_int32_T;
            } else {
              qY = (q0 + mfID) + 1;
            }
            varargin_2_data[qY - 1] = 1.0 - 2.0 * b_value * b_value;
          }
          if (((d + d1) / 2.0 < d2) && (d2 <= d1)) {
            b_value = (d1 - d2) * (1.0 / (d - d1));
            if (b) {
              qY = MIN_int32_T;
            } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
              qY = MAX_int32_T;
            } else {
              qY = (q0 + mfID) + 1;
            }
            varargin_2_data[qY - 1] = 2.0 * b_value * b_value;
          }
          if (d1 <= d2) {
            if (b) {
              qY = MIN_int32_T;
            } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
              qY = MAX_int32_T;
            } else {
              qY = (q0 + mfID) + 1;
            }
            varargin_2_data[qY - 1] = 0.0;
          }
        }
      } else if (b_isequal(varargin_1[inputID].f1->data[mfID].type, uv7)) {
        if (b) {
          qY = MIN_int32_T;
        } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
          qY = MAX_int32_T;
        } else {
          qY = (q0 + mfID) + 1;
        }
        varargin_2_data[qY - 1] = 0.0;
        d = varargin_1[inputID].f1->data[mfID].params->data[1];
        d1 = inputs[inputID];
        if (d1 >= d) {
          if (b) {
            qY = MIN_int32_T;
          } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
            qY = MAX_int32_T;
          } else {
            qY = (q0 + mfID) + 1;
          }
          varargin_2_data[qY - 1] = 1.0;
        } else {
          d2 = varargin_1[inputID].f1->data[mfID].params->data[0];
          if (d1 >= d2) {
            if (b) {
              qY = MIN_int32_T;
            } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
              qY = MAX_int32_T;
            } else {
              qY = (q0 + mfID) + 1;
            }
            varargin_2_data[qY - 1] = (d1 - d2) * (1.0 / (d - d2));
          }
        }
      } else if (b_isequal(varargin_1[inputID].f1->data[mfID].type, uv8)) {
        if (b) {
          qY = MIN_int32_T;
        } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
          qY = MAX_int32_T;
        } else {
          qY = (q0 + mfID) + 1;
        }
        varargin_2_data[qY - 1] = 0.0;
        d = varargin_1[inputID].f1->data[mfID].params->data[0];
        d1 = inputs[inputID];
        if (d1 < d) {
          if (b) {
            qY = MIN_int32_T;
          } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
            qY = MAX_int32_T;
          } else {
            qY = (q0 + mfID) + 1;
          }
          varargin_2_data[qY - 1] = 1.0;
        } else {
          d2 = varargin_1[inputID].f1->data[mfID].params->data[1];
          if (d1 < d2) {
            if (b) {
              qY = MIN_int32_T;
            } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
              qY = MAX_int32_T;
            } else {
              qY = (q0 + mfID) + 1;
            }
            varargin_2_data[qY - 1] = (d2 - d1) * (1.0 / (d2 - d));
          }
        }
      } else if (e_isequal(varargin_1[inputID].f1->data[mfID].type, uv9)) {
        d = varargin_1[inputID].f1->data[mfID].params->data[1];
        d1 = inputs[inputID];
        c1Index = (d1 <= d);
        d2 = varargin_1[inputID].f1->data[mfID].params->data[3];
        c2Index = (d1 >= d2);
        y = d1 - d;
        b_value = d1 - d2;
        d = varargin_1[inputID].f1->data[mfID].params->data[0];
        d1 = varargin_1[inputID].f1->data[mfID].params->data[2];
        if (b) {
          qY = MIN_int32_T;
        } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
          qY = MAX_int32_T;
        } else {
          qY = (q0 + mfID) + 1;
        }
        varargin_2_data[qY - 1] =
            (exp(-(y * y) / (2.0 * (d * d))) * (double)c1Index +
             (1.0 - (double)c1Index)) *
            (exp(-(b_value * b_value) / (2.0 * (d1 * d1))) * (double)c2Index +
             (1.0 - (double)c2Index));
      } else if (b_isequal(varargin_1[inputID].f1->data[mfID].type, uv10)) {
        if (b) {
          qY = MIN_int32_T;
        } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
          qY = MAX_int32_T;
        } else {
          qY = (q0 + mfID) + 1;
        }
        d = inputs[inputID];
        varargin_2_data[qY - 1] = fabs(
            1.0 /
                (exp(-varargin_1[inputID].f1->data[mfID].params->data[0] *
                     (d - varargin_1[inputID].f1->data[mfID].params->data[1])) +
                 1.0) -
            1.0 /
                (exp(-varargin_1[inputID].f1->data[mfID].params->data[2] *
                     (d - varargin_1[inputID].f1->data[mfID].params->data[3])) +
                 1.0));
      } else if (b_isequal(varargin_1[inputID].f1->data[mfID].type, uv11)) {
        if (b) {
          qY = MIN_int32_T;
        } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
          qY = MAX_int32_T;
        } else {
          qY = (q0 + mfID) + 1;
        }
        d = inputs[inputID];
        varargin_2_data[qY - 1] =
            1.0 /
            (exp(-varargin_1[inputID].f1->data[mfID].params->data[0] *
                 (d - varargin_1[inputID].f1->data[mfID].params->data[1])) +
             1.0) *
            (1.0 /
             (exp(-varargin_1[inputID].f1->data[mfID].params->data[2] *
                  (d - varargin_1[inputID].f1->data[mfID].params->data[3])) +
              1.0));
      } else {
        qY = varargin_1[inputID].f1->data[mfID].type->size[1];
        c1Index = (qY == 4);
        if (c1Index && (qY != 0)) {
          qY = 0;
          exitg1 = false;
          while ((!exitg1) && (qY < 4)) {
            if ((unsigned char)varargin_1[inputID]
                    .f1->data[mfID]
                    .type->data[qY] != uv12[qY]) {
              c1Index = false;
              exitg1 = true;
            } else {
              qY++;
            }
          }
        }
        if (c1Index) {
          d = varargin_1[inputID].f1->data[mfID].params->data[0];
          d1 = varargin_1[inputID].f1->data[mfID].params->data[1];
          if (d >= d1) {
            d2 = inputs[inputID];
            y = (d2 >= (d + d1) / 2.0);
          } else {
            y = 0.0;
            d2 = inputs[inputID];
            if ((d < d2) && (d2 <= (d + d1) / 2.0)) {
              b_value = (d2 - d) * (1.0 / (d1 - d));
              y = 2.0 * b_value * b_value;
            }
            if (((d + d1) / 2.0 < d2) && (d2 <= d1)) {
              b_value = (d1 - d2) * (1.0 / (d1 - d));
              y = 1.0 - 2.0 * b_value * b_value;
            }
            if (d1 <= d2) {
              y = 1.0;
            }
          }
          d = varargin_1[inputID].f1->data[mfID].params->data[2];
          d1 = varargin_1[inputID].f1->data[mfID].params->data[3];
          if (d >= d1) {
            b_value = (d2 <= (d + d1) / 2.0);
          } else {
            b_value = 0.0;
            if (d2 <= d) {
              b_value = 1.0;
            }
            if ((d < d2) && (d2 <= (d + d1) / 2.0)) {
              b_value = (d2 - d) * (1.0 / (d - d1));
              b_value = 1.0 - 2.0 * b_value * b_value;
            }
            if (((d + d1) / 2.0 < d2) && (d2 <= d1)) {
              b_value = (d1 - d2) * (1.0 / (d - d1));
              b_value *= 2.0 * b_value;
            }
            if (d1 <= d2) {
              b_value = 0.0;
            }
          }
          q0 = fis_numCumInputMFs[inputID];
          if (b) {
            qY = MIN_int32_T;
          } else if ((q0 > 0) && (mfID + 1 > MAX_int32_T - q0)) {
            qY = MAX_int32_T;
          } else {
            qY = (q0 + mfID) + 1;
          }
          varargin_2_data[qY - 1] = y * b_value;
        } else {
          exit(0);
        }
      }
    }
  }
  for (inputID = 0; inputID < 8; inputID++) {
    d = fis_antecedent[inputID];
    d1 = rt_roundd_snf(fabs(d));
    if (d1 < 2.147483648E+9) {
      numMFs = (int)d1;
    } else if (d1 >= 2.147483648E+9) {
      numMFs = MAX_int32_T;
    } else {
      numMFs = 0;
    }
    if (numMFs == 0) {
      fuzzifiedInputs[inputID] = (fis_connection[inputID] == 1.0);
    } else {
      if (fis_numCumInputMFs[0] <= MIN_int32_T) {
        qY = MAX_int32_T;
      } else {
        qY = -fis_numCumInputMFs[0];
      }
      if (fis_numCumInputMFs[0] < 0) {
        q0 = qY;
      } else {
        q0 = fis_numCumInputMFs[0];
      }
      if ((q0 < 0) && (numMFs < MIN_int32_T - q0)) {
        qY = MIN_int32_T;
      } else if ((q0 > 0) && (numMFs > MAX_int32_T - q0)) {
        qY = MAX_int32_T;
      } else {
        qY = q0 + numMFs;
      }
      d1 = varargin_2_data[qY - 1];
      fuzzifiedInputs[inputID] = d1;
      if (d < 0.0) {
        d1 = 1.0 - d1;
        fuzzifiedInputs[inputID] = d1;
      }
    }
    d = fis_antecedent[inputID + 8];
    d1 = rt_roundd_snf(fabs(d));
    if (d1 < 2.147483648E+9) {
      numMFs = (int)d1;
    } else if (d1 >= 2.147483648E+9) {
      numMFs = MAX_int32_T;
    } else {
      numMFs = 0;
    }
    if (numMFs == 0) {
      fuzzifiedInputs[inputID + 8] = (fis_connection[inputID] == 1.0);
    } else {
      if (fis_numCumInputMFs[1] <= MIN_int32_T) {
        qY = MAX_int32_T;
      } else {
        qY = -fis_numCumInputMFs[1];
      }
      if (fis_numCumInputMFs[1] < 0) {
        q0 = qY;
      } else {
        q0 = fis_numCumInputMFs[1];
      }
      if ((q0 < 0) && (numMFs < MIN_int32_T - q0)) {
        qY = MIN_int32_T;
      } else if ((q0 > 0) && (numMFs > MAX_int32_T - q0)) {
        qY = MAX_int32_T;
      } else {
        qY = q0 + numMFs;
      }
      d1 = varargin_2_data[qY - 1];
      fuzzifiedInputs[inputID + 8] = d1;
      if (d < 0.0) {
        d1 = 1.0 - d1;
        fuzzifiedInputs[inputID + 8] = d1;
      }
    }
    d = fis_antecedent[inputID + 16];
    d1 = rt_roundd_snf(fabs(d));
    if (d1 < 2.147483648E+9) {
      numMFs = (int)d1;
    } else if (d1 >= 2.147483648E+9) {
      numMFs = MAX_int32_T;
    } else {
      numMFs = 0;
    }
    if (numMFs == 0) {
      fuzzifiedInputs[inputID + 16] = (fis_connection[inputID] == 1.0);
    } else {
      if (fis_numCumInputMFs[2] <= MIN_int32_T) {
        qY = MAX_int32_T;
      } else {
        qY = -fis_numCumInputMFs[2];
      }
      if (fis_numCumInputMFs[2] < 0) {
        q0 = qY;
      } else {
        q0 = fis_numCumInputMFs[2];
      }
      if ((q0 < 0) && (numMFs < MIN_int32_T - q0)) {
        qY = MIN_int32_T;
      } else if ((q0 > 0) && (numMFs > MAX_int32_T - q0)) {
        qY = MAX_int32_T;
      } else {
        qY = q0 + numMFs;
      }
      d1 = varargin_2_data[qY - 1];
      fuzzifiedInputs[inputID + 16] = d1;
      if (d < 0.0) {
        d1 = 1.0 - d1;
        fuzzifiedInputs[inputID + 16] = d1;
      }
    }
  }
}

/* End of code generation (fuzzifyInputs.c) */
