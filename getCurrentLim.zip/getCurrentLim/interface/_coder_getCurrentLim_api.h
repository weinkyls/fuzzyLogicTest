/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_getCurrentLim_api.h
 *
 * Code generation for function 'getCurrentLim'
 *
 */

#ifndef _CODER_GETCURRENTLIM_API_H
#define _CODER_GETCURRENTLIM_API_H

/* Include files */
#include "emlrt.h"
#include "mex.h"
#include "tmwtypes.h"
#include <string.h>

/* Type Definitions */
#ifndef typedef_struct2_T
#define typedef_struct2_T
typedef struct {
  char_T name[10];
  real_T origNameLength;
  char_T type[6];
  real_T origTypeLength;
  real_T params[4];
  real_T origParamLength;
} struct2_T;
#endif /* typedef_struct2_T */

#ifndef typedef_struct1_T
#define typedef_struct1_T
typedef struct {
  char_T name[17];
  real_T origNameLength;
  real_T range[2];
  struct2_T mf[2];
  real_T origNumMF;
} struct1_T;
#endif /* typedef_struct1_T */

#ifndef typedef_struct4_T
#define typedef_struct4_T
typedef struct {
  char_T name[14];
  real_T origNameLength;
  char_T type[8];
  real_T origTypeLength;
  real_T params;
  real_T origParamLength;
} struct4_T;
#endif /* typedef_struct4_T */

#ifndef typedef_struct3_T
#define typedef_struct3_T
typedef struct {
  char_T name[7];
  real_T origNameLength;
  real_T range[2];
  struct4_T mf[5];
  real_T origNumMF;
} struct3_T;
#endif /* typedef_struct3_T */

#ifndef typedef_struct5_T
#define typedef_struct5_T
typedef struct {
  real_T antecedent[3];
  real_T consequent;
  real_T weight;
  real_T connection;
} struct5_T;
#endif /* typedef_struct5_T */

#ifndef typedef_struct0_T
#define typedef_struct0_T
typedef struct {
  char_T name[9];
  char_T type[6];
  char_T andMethod[4];
  char_T orMethod[6];
  char_T defuzzMethod[6];
  char_T impMethod[4];
  char_T aggMethod[3];
  struct1_T input[3];
  struct3_T output;
  struct5_T rule[8];
} struct0_T;
#endif /* typedef_struct0_T */

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
real_T getCurrentLim(struct0_T *fisData, real_T temp_cell, real_T rpm_mot,
                     real_T energy_margin);

void getCurrentLim_api(const mxArray *const prhs[4], const mxArray **plhs);

void getCurrentLim_atexit(void);

void getCurrentLim_initialize(void);

void getCurrentLim_terminate(void);

void getCurrentLim_xil_shutdown(void);

void getCurrentLim_xil_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (_coder_getCurrentLim_api.h) */
