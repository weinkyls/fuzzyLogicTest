/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getCurrentLim_emxutil.h
 *
 * Code generation for function 'getCurrentLim_emxutil'
 *
 */

#ifndef GETCURRENTLIM_EMXUTIL_H
#define GETCURRENTLIM_EMXUTIL_H

/* Include files */
#include "getCurrentLim_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void emxCopyStruct_struct_T(d_struct_T *dst, const d_struct_T *src);

extern void emxCopyStruct_struct_T1(c_struct_T *dst, const c_struct_T *src);

extern void emxCopyStruct_struct_T2(struct_T *dst, const struct_T *src);

extern void emxCopyStruct_struct_T3(b_struct_T *dst, const b_struct_T *src);

extern void emxCopyStruct_struct_T4(e_struct_T *dst, const e_struct_T *src);

extern void emxCopy_char_T(emxArray_char_T **dst, emxArray_char_T *const *src);

extern void emxCopy_real_T(emxArray_real_T **dst, emxArray_real_T *const *src);

extern void emxCopy_struct_T(b_emxArray_struct_T **dst,
                             b_emxArray_struct_T *const *src);

extern void emxCopy_struct_T1(emxArray_struct_T **dst,
                              emxArray_struct_T *const *src);

extern void emxEnsureCapacity_char_T(emxArray_char_T *emxArray, int oldNumel);

extern void emxEnsureCapacity_real_T(emxArray_real_T *emxArray, int oldNumel);

extern void emxEnsureCapacity_struct_T(b_emxArray_struct_T *emxArray,
                                       int oldNumel);

extern void emxEnsureCapacity_struct_T1(emxArray_struct_T *emxArray,
                                        int oldNumel);

extern void emxEnsureCapacity_struct_T2(c_emxArray_struct_T *emxArray,
                                        int oldNumel);

extern void emxExpand_struct_T(b_emxArray_struct_T *emxArray, int fromIndex,
                               int toIndex);

extern void emxExpand_struct_T1(emxArray_struct_T *emxArray, int fromIndex,
                                int toIndex);

extern void emxExpand_struct_T2(c_emxArray_struct_T *emxArray, int fromIndex,
                                int toIndex);

extern void emxFreeMatrix_cell_wrap_0(cell_wrap_0 pMatrix[3]);

extern void emxFreeMatrix_struct_T(b_struct_T pMatrix[3]);

extern void emxFreeMatrix_struct_T1(d_struct_T pMatrix[3]);

extern void emxFreeStruct_cell_wrap_0(cell_wrap_0 *pStruct);

extern void emxFreeStruct_struct_T(c_struct_T *pStruct);

extern void emxFreeStruct_struct_T1(struct_T *pStruct);

extern void emxFreeStruct_struct_T2(b_struct_T *pStruct);

extern void emxFreeStruct_struct_T3(d_struct_T *pStruct);

extern void emxFreeStruct_struct_T4(e_struct_T *pStruct);

extern void emxFree_char_T(emxArray_char_T **pEmxArray);

extern void emxFree_real_T(emxArray_real_T **pEmxArray);

extern void emxFree_struct_T(emxArray_struct_T **pEmxArray);

extern void emxFree_struct_T1(b_emxArray_struct_T **pEmxArray);

extern void emxFree_struct_T2(c_emxArray_struct_T **pEmxArray);

extern void emxInitMatrix_cell_wrap_0(cell_wrap_0 pMatrix[3]);

extern void emxInitMatrix_struct_T(b_struct_T pMatrix[3]);

extern void emxInitMatrix_struct_T1(d_struct_T pMatrix[3]);

extern void emxInitStruct_cell_wrap_0(cell_wrap_0 *pStruct);

extern void emxInitStruct_struct_T(c_struct_T *pStruct);

extern void emxInitStruct_struct_T1(struct_T *pStruct);

extern void emxInitStruct_struct_T2(b_struct_T *pStruct);

extern void emxInitStruct_struct_T3(d_struct_T *pStruct);

extern void emxInitStruct_struct_T4(e_struct_T *pStruct);

extern void emxInit_char_T(emxArray_char_T **pEmxArray);

extern void emxInit_real_T(emxArray_real_T **pEmxArray, int numDimensions);

extern void emxInit_struct_T(emxArray_struct_T **pEmxArray);

extern void emxInit_struct_T1(b_emxArray_struct_T **pEmxArray);

extern void emxInit_struct_T2(c_emxArray_struct_T **pEmxArray);

extern void emxTrim_struct_T(b_emxArray_struct_T *emxArray, int fromIndex,
                             int toIndex);

extern void emxTrim_struct_T1(emxArray_struct_T *emxArray, int fromIndex,
                              int toIndex);

extern void emxTrim_struct_T2(c_emxArray_struct_T *emxArray, int fromIndex,
                              int toIndex);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (getCurrentLim_emxutil.h) */
