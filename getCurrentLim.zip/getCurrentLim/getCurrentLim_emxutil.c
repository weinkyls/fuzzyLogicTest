/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getCurrentLim_emxutil.c
 *
 * Code generation for function 'getCurrentLim_emxutil'
 *
 */

/* Include files */
#include "getCurrentLim_emxutil.h"
#include "getCurrentLim_types.h"
#include "rt_nonfinite.h"
#include <stdlib.h>
#include <string.h>

/* Function Definitions */
void emxCopyStruct_struct_T(d_struct_T *dst, const d_struct_T *src)
{
  emxCopy_struct_T(&dst->mf, &src->mf);
  dst->origNumMF = src->origNumMF;
}

void emxCopyStruct_struct_T1(c_struct_T *dst, const c_struct_T *src)
{
  emxCopy_char_T(&dst->type, &src->type);
  dst->origTypeLength = src->origTypeLength;
  emxCopy_real_T(&dst->params, &src->params);
  dst->origParamLength = src->origParamLength;
}

void emxCopyStruct_struct_T2(struct_T *dst, const struct_T *src)
{
  emxCopy_char_T(&dst->type, &src->type);
  dst->origTypeLength = src->origTypeLength;
  emxCopy_real_T(&dst->params, &src->params);
  dst->origParamLength = src->origParamLength;
}

void emxCopyStruct_struct_T3(b_struct_T *dst, const b_struct_T *src)
{
  emxCopy_struct_T1(&dst->mf, &src->mf);
  dst->origNumMF = src->origNumMF;
}

void emxCopyStruct_struct_T4(e_struct_T *dst, const e_struct_T *src)
{
  emxCopy_char_T(&dst->type, &src->type);
  emxCopy_real_T(&dst->params, &src->params);
}

void emxCopy_char_T(emxArray_char_T **dst, emxArray_char_T *const *src)
{
  int i;
  int numElDst;
  int numElSrc;
  numElDst = 1;
  numElSrc = 1;
  for (i = 0; i < (*dst)->numDimensions; i++) {
    numElDst *= (*dst)->size[i];
    numElSrc *= (*src)->size[i];
  }
  for (i = 0; i < (*dst)->numDimensions; i++) {
    (*dst)->size[i] = (*src)->size[i];
  }
  emxEnsureCapacity_char_T(*dst, numElDst);
  for (i = 0; i < numElSrc; i++) {
    (*dst)->data[i] = (*src)->data[i];
  }
}

void emxCopy_real_T(emxArray_real_T **dst, emxArray_real_T *const *src)
{
  int i;
  int numElDst;
  int numElSrc;
  numElDst = 1;
  numElSrc = 1;
  for (i = 0; i < (*dst)->numDimensions; i++) {
    numElDst *= (*dst)->size[i];
    numElSrc *= (*src)->size[i];
  }
  for (i = 0; i < (*dst)->numDimensions; i++) {
    (*dst)->size[i] = (*src)->size[i];
  }
  emxEnsureCapacity_real_T(*dst, numElDst);
  for (i = 0; i < numElSrc; i++) {
    (*dst)->data[i] = (*src)->data[i];
  }
}

void emxCopy_struct_T(b_emxArray_struct_T **dst,
                      b_emxArray_struct_T *const *src)
{
  int i;
  int numElDst;
  int numElSrc;
  numElDst = 1;
  numElSrc = 1;
  for (i = 0; i < (*dst)->numDimensions; i++) {
    numElDst *= (*dst)->size[i];
    numElSrc *= (*src)->size[i];
  }
  for (i = 0; i < (*dst)->numDimensions; i++) {
    (*dst)->size[i] = (*src)->size[i];
  }
  emxEnsureCapacity_struct_T(*dst, numElDst);
  for (i = 0; i < numElSrc; i++) {
    emxCopyStruct_struct_T1(&(*dst)->data[i], &(*src)->data[i]);
  }
}

void emxCopy_struct_T1(emxArray_struct_T **dst, emxArray_struct_T *const *src)
{
  int i;
  int numElDst;
  int numElSrc;
  numElDst = 1;
  numElSrc = 1;
  for (i = 0; i < (*dst)->numDimensions; i++) {
    numElDst *= (*dst)->size[i];
    numElSrc *= (*src)->size[i];
  }
  for (i = 0; i < (*dst)->numDimensions; i++) {
    (*dst)->size[i] = (*src)->size[i];
  }
  emxEnsureCapacity_struct_T1(*dst, numElDst);
  for (i = 0; i < numElSrc; i++) {
    emxCopyStruct_struct_T2(&(*dst)->data[i], &(*src)->data[i]);
  }
}

void emxEnsureCapacity_char_T(emxArray_char_T *emxArray, int oldNumel)
{
  int i;
  int newNumel;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }
  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }
  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }
    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i *= 2;
      }
    }
    newData = malloc((unsigned int)i * sizeof(char));
    if (emxArray->data != NULL) {
      memcpy(newData, emxArray->data, sizeof(char) * (unsigned int)oldNumel);
      if (emxArray->canFreeData) {
        free(emxArray->data);
      }
    }
    emxArray->data = (char *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
}

void emxEnsureCapacity_real_T(emxArray_real_T *emxArray, int oldNumel)
{
  int i;
  int newNumel;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }
  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }
  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }
    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i *= 2;
      }
    }
    newData = malloc((unsigned int)i * sizeof(double));
    if (emxArray->data != NULL) {
      memcpy(newData, emxArray->data, sizeof(double) * (unsigned int)oldNumel);
      if (emxArray->canFreeData) {
        free(emxArray->data);
      }
    }
    emxArray->data = (double *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
}

void emxEnsureCapacity_struct_T(b_emxArray_struct_T *emxArray, int oldNumel)
{
  int i;
  int newNumel;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }
  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }
  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }
    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i *= 2;
      }
    }
    newData = calloc((unsigned int)i, sizeof(c_struct_T));
    if (emxArray->data != NULL) {
      memcpy(newData, emxArray->data,
             sizeof(c_struct_T) * (unsigned int)oldNumel);
      if (emxArray->canFreeData) {
        free(emxArray->data);
      }
    }
    emxArray->data = (c_struct_T *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
  if (oldNumel > newNumel) {
    emxTrim_struct_T(emxArray, newNumel, oldNumel);
  } else if (oldNumel < newNumel) {
    emxExpand_struct_T(emxArray, oldNumel, newNumel);
  }
}

void emxEnsureCapacity_struct_T1(emxArray_struct_T *emxArray, int oldNumel)
{
  int i;
  int newNumel;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }
  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }
  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }
    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i *= 2;
      }
    }
    newData = calloc((unsigned int)i, sizeof(struct_T));
    if (emxArray->data != NULL) {
      memcpy(newData, emxArray->data,
             sizeof(struct_T) * (unsigned int)oldNumel);
      if (emxArray->canFreeData) {
        free(emxArray->data);
      }
    }
    emxArray->data = (struct_T *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
  if (oldNumel > newNumel) {
    emxTrim_struct_T1(emxArray, newNumel, oldNumel);
  } else if (oldNumel < newNumel) {
    emxExpand_struct_T1(emxArray, oldNumel, newNumel);
  }
}

void emxEnsureCapacity_struct_T2(c_emxArray_struct_T *emxArray, int oldNumel)
{
  int i;
  int newNumel;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }
  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }
  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }
    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i *= 2;
      }
    }
    newData = calloc((unsigned int)i, sizeof(e_struct_T));
    if (emxArray->data != NULL) {
      memcpy(newData, emxArray->data,
             sizeof(e_struct_T) * (unsigned int)oldNumel);
      if (emxArray->canFreeData) {
        free(emxArray->data);
      }
    }
    emxArray->data = (e_struct_T *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
  if (oldNumel > newNumel) {
    emxTrim_struct_T2(emxArray, newNumel, oldNumel);
  } else if (oldNumel < newNumel) {
    emxExpand_struct_T2(emxArray, oldNumel, newNumel);
  }
}

void emxExpand_struct_T(b_emxArray_struct_T *emxArray, int fromIndex,
                        int toIndex)
{
  int i;
  for (i = fromIndex; i < toIndex; i++) {
    emxInitStruct_struct_T(&emxArray->data[i]);
  }
}

void emxExpand_struct_T1(emxArray_struct_T *emxArray, int fromIndex,
                         int toIndex)
{
  int i;
  for (i = fromIndex; i < toIndex; i++) {
    emxInitStruct_struct_T1(&emxArray->data[i]);
  }
}

void emxExpand_struct_T2(c_emxArray_struct_T *emxArray, int fromIndex,
                         int toIndex)
{
  int i;
  for (i = fromIndex; i < toIndex; i++) {
    emxInitStruct_struct_T4(&emxArray->data[i]);
  }
}

void emxFreeMatrix_cell_wrap_0(cell_wrap_0 pMatrix[3])
{
  int i;
  for (i = 0; i < 3; i++) {
    emxFreeStruct_cell_wrap_0(&pMatrix[i]);
  }
}

void emxFreeMatrix_struct_T(b_struct_T pMatrix[3])
{
  int i;
  for (i = 0; i < 3; i++) {
    emxFreeStruct_struct_T2(&pMatrix[i]);
  }
}

void emxFreeMatrix_struct_T1(d_struct_T pMatrix[3])
{
  int i;
  for (i = 0; i < 3; i++) {
    emxFreeStruct_struct_T3(&pMatrix[i]);
  }
}

void emxFreeStruct_cell_wrap_0(cell_wrap_0 *pStruct)
{
  emxFree_struct_T2(&pStruct->f1);
}

void emxFreeStruct_struct_T(c_struct_T *pStruct)
{
  emxFree_char_T(&pStruct->type);
  emxFree_real_T(&pStruct->params);
}

void emxFreeStruct_struct_T1(struct_T *pStruct)
{
  emxFree_char_T(&pStruct->type);
  emxFree_real_T(&pStruct->params);
}

void emxFreeStruct_struct_T2(b_struct_T *pStruct)
{
  emxFree_struct_T(&pStruct->mf);
}

void emxFreeStruct_struct_T3(d_struct_T *pStruct)
{
  emxFree_struct_T1(&pStruct->mf);
}

void emxFreeStruct_struct_T4(e_struct_T *pStruct)
{
  emxFree_char_T(&pStruct->type);
  emxFree_real_T(&pStruct->params);
}

void emxFree_char_T(emxArray_char_T **pEmxArray)
{
  if (*pEmxArray != (emxArray_char_T *)NULL) {
    if (((*pEmxArray)->data != (char *)NULL) && (*pEmxArray)->canFreeData) {
      free((*pEmxArray)->data);
    }
    free((*pEmxArray)->size);
    free(*pEmxArray);
    *pEmxArray = (emxArray_char_T *)NULL;
  }
}

void emxFree_real_T(emxArray_real_T **pEmxArray)
{
  if (*pEmxArray != (emxArray_real_T *)NULL) {
    if (((*pEmxArray)->data != (double *)NULL) && (*pEmxArray)->canFreeData) {
      free((*pEmxArray)->data);
    }
    free((*pEmxArray)->size);
    free(*pEmxArray);
    *pEmxArray = (emxArray_real_T *)NULL;
  }
}

void emxFree_struct_T(emxArray_struct_T **pEmxArray)
{
  int i;
  int numEl;
  if (*pEmxArray != (emxArray_struct_T *)NULL) {
    if ((*pEmxArray)->data != (struct_T *)NULL) {
      numEl = 1;
      for (i = 0; i < (*pEmxArray)->numDimensions; i++) {
        numEl *= (*pEmxArray)->size[i];
      }
      for (i = 0; i < numEl; i++) {
        emxFreeStruct_struct_T1(&(*pEmxArray)->data[i]);
      }
      if ((*pEmxArray)->canFreeData) {
        free((*pEmxArray)->data);
      }
    }
    free((*pEmxArray)->size);
    free(*pEmxArray);
    *pEmxArray = (emxArray_struct_T *)NULL;
  }
}

void emxFree_struct_T1(b_emxArray_struct_T **pEmxArray)
{
  int i;
  int numEl;
  if (*pEmxArray != (b_emxArray_struct_T *)NULL) {
    if ((*pEmxArray)->data != (c_struct_T *)NULL) {
      numEl = 1;
      for (i = 0; i < (*pEmxArray)->numDimensions; i++) {
        numEl *= (*pEmxArray)->size[i];
      }
      for (i = 0; i < numEl; i++) {
        emxFreeStruct_struct_T(&(*pEmxArray)->data[i]);
      }
      if ((*pEmxArray)->canFreeData) {
        free((*pEmxArray)->data);
      }
    }
    free((*pEmxArray)->size);
    free(*pEmxArray);
    *pEmxArray = (b_emxArray_struct_T *)NULL;
  }
}

void emxFree_struct_T2(c_emxArray_struct_T **pEmxArray)
{
  int i;
  int numEl;
  if (*pEmxArray != (c_emxArray_struct_T *)NULL) {
    if ((*pEmxArray)->data != (e_struct_T *)NULL) {
      numEl = 1;
      for (i = 0; i < (*pEmxArray)->numDimensions; i++) {
        numEl *= (*pEmxArray)->size[i];
      }
      for (i = 0; i < numEl; i++) {
        emxFreeStruct_struct_T4(&(*pEmxArray)->data[i]);
      }
      if ((*pEmxArray)->canFreeData) {
        free((*pEmxArray)->data);
      }
    }
    free((*pEmxArray)->size);
    free(*pEmxArray);
    *pEmxArray = (c_emxArray_struct_T *)NULL;
  }
}

void emxInitMatrix_cell_wrap_0(cell_wrap_0 pMatrix[3])
{
  int i;
  for (i = 0; i < 3; i++) {
    emxInitStruct_cell_wrap_0(&pMatrix[i]);
  }
}

void emxInitMatrix_struct_T(b_struct_T pMatrix[3])
{
  int i;
  for (i = 0; i < 3; i++) {
    emxInitStruct_struct_T2(&pMatrix[i]);
  }
}

void emxInitMatrix_struct_T1(d_struct_T pMatrix[3])
{
  int i;
  for (i = 0; i < 3; i++) {
    emxInitStruct_struct_T3(&pMatrix[i]);
  }
}

void emxInitStruct_cell_wrap_0(cell_wrap_0 *pStruct)
{
  emxInit_struct_T2(&pStruct->f1);
}

void emxInitStruct_struct_T(c_struct_T *pStruct)
{
  emxInit_char_T(&pStruct->type);
  emxInit_real_T(&pStruct->params, 2);
}

void emxInitStruct_struct_T1(struct_T *pStruct)
{
  emxInit_char_T(&pStruct->type);
  emxInit_real_T(&pStruct->params, 2);
}

void emxInitStruct_struct_T2(b_struct_T *pStruct)
{
  emxInit_struct_T(&pStruct->mf);
}

void emxInitStruct_struct_T3(d_struct_T *pStruct)
{
  emxInit_struct_T1(&pStruct->mf);
}

void emxInitStruct_struct_T4(e_struct_T *pStruct)
{
  emxInit_char_T(&pStruct->type);
  emxInit_real_T(&pStruct->params, 2);
}

void emxInit_char_T(emxArray_char_T **pEmxArray)
{
  emxArray_char_T *emxArray;
  int i;
  *pEmxArray = (emxArray_char_T *)malloc(sizeof(emxArray_char_T));
  emxArray = *pEmxArray;
  emxArray->data = (char *)NULL;
  emxArray->numDimensions = 2;
  emxArray->size = (int *)malloc(sizeof(int) * 2U);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < 2; i++) {
    emxArray->size[i] = 0;
  }
}

void emxInit_real_T(emxArray_real_T **pEmxArray, int numDimensions)
{
  emxArray_real_T *emxArray;
  int i;
  *pEmxArray = (emxArray_real_T *)malloc(sizeof(emxArray_real_T));
  emxArray = *pEmxArray;
  emxArray->data = (double *)NULL;
  emxArray->numDimensions = numDimensions;
  emxArray->size = (int *)malloc(sizeof(int) * (unsigned int)numDimensions);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < numDimensions; i++) {
    emxArray->size[i] = 0;
  }
}

void emxInit_struct_T(emxArray_struct_T **pEmxArray)
{
  emxArray_struct_T *emxArray;
  int i;
  *pEmxArray = (emxArray_struct_T *)malloc(sizeof(emxArray_struct_T));
  emxArray = *pEmxArray;
  emxArray->data = (struct_T *)NULL;
  emxArray->numDimensions = 2;
  emxArray->size = (int *)malloc(sizeof(int) * 2U);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < 2; i++) {
    emxArray->size[i] = 0;
  }
}

void emxInit_struct_T1(b_emxArray_struct_T **pEmxArray)
{
  b_emxArray_struct_T *emxArray;
  int i;
  *pEmxArray = (b_emxArray_struct_T *)malloc(sizeof(b_emxArray_struct_T));
  emxArray = *pEmxArray;
  emxArray->data = (c_struct_T *)NULL;
  emxArray->numDimensions = 2;
  emxArray->size = (int *)malloc(sizeof(int) * 2U);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < 2; i++) {
    emxArray->size[i] = 0;
  }
}

void emxInit_struct_T2(c_emxArray_struct_T **pEmxArray)
{
  c_emxArray_struct_T *emxArray;
  int i;
  *pEmxArray = (c_emxArray_struct_T *)malloc(sizeof(c_emxArray_struct_T));
  emxArray = *pEmxArray;
  emxArray->data = (e_struct_T *)NULL;
  emxArray->numDimensions = 2;
  emxArray->size = (int *)malloc(sizeof(int) * 2U);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < 2; i++) {
    emxArray->size[i] = 0;
  }
}

void emxTrim_struct_T(b_emxArray_struct_T *emxArray, int fromIndex, int toIndex)
{
  int i;
  for (i = fromIndex; i < toIndex; i++) {
    emxFreeStruct_struct_T(&emxArray->data[i]);
  }
}

void emxTrim_struct_T1(emxArray_struct_T *emxArray, int fromIndex, int toIndex)
{
  int i;
  for (i = fromIndex; i < toIndex; i++) {
    emxFreeStruct_struct_T1(&emxArray->data[i]);
  }
}

void emxTrim_struct_T2(c_emxArray_struct_T *emxArray, int fromIndex,
                       int toIndex)
{
  int i;
  for (i = fromIndex; i < toIndex; i++) {
    emxFreeStruct_struct_T4(&emxArray->data[i]);
  }
}

/* End of code generation (getCurrentLim_emxutil.c) */
