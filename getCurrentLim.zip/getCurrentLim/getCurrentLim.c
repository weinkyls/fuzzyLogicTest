/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getCurrentLim.c
 *
 * Code generation for function 'getCurrentLim'
 *
 */

/* Include files */
#include "getCurrentLim.h"
#include "evalfis.h"
#include "getCurrentLim_data.h"
#include "getCurrentLim_initialize.h"
#include "getCurrentLim_types.h"
#include "rt_nonfinite.h"

/* Function Definitions */
double getCurrentLim(const struct0_T *fisData, double temp_cell, double rpm_mot,
                     double energy_margin)
{
  double b_temp_cell[3];
  if (!isInitialized_getCurrentLim) {
    getCurrentLim_initialize();
  }
  b_temp_cell[0] = temp_cell;
  b_temp_cell[1] = rpm_mot;
  b_temp_cell[2] = energy_margin;
  return evalfis(fisData->andMethod, fisData->orMethod, fisData->defuzzMethod,
                 fisData->input, fisData->output.range, fisData->output.mf,
                 fisData->output.origNumMF, fisData->rule, b_temp_cell);
}

/* End of code generation (getCurrentLim.c) */
