/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getCurrentLim_data.h
 *
 * Code generation for function 'getCurrentLim_data'
 *
 */

#ifndef GETCURRENTLIM_DATA_H
#define GETCURRENTLIM_DATA_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern boolean_T isInitialized_getCurrentLim;

#endif
/* End of code generation (getCurrentLim_data.h) */
