/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * evalfis.h
 *
 * Code generation for function 'evalfis'
 *
 */

#ifndef EVALFIS_H
#define EVALFIS_H

/* Include files */
#include "getCurrentLim_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
double evalfis(const char arg1_andMethod[4], const char arg1_orMethod[6],
               const char arg1_defuzzMethod[6], const struct1_T arg1_input[3],
               const double arg1_output_range[2],
               const struct4_T arg1_output_mf[5], double arg1_output_origNumMF,
               const struct5_T arg1_rule[8], const double arg2[3]);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (evalfis.h) */
