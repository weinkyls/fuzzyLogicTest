/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getCurrentLim_rtwutil.h
 *
 * Code generation for function 'getCurrentLim_rtwutil'
 *
 */

#ifndef GETCURRENTLIM_RTWUTIL_H
#define GETCURRENTLIM_RTWUTIL_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern double rt_roundd_snf(double u);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (getCurrentLim_rtwutil.h) */
