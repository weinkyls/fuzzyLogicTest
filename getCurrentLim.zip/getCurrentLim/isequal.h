/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * isequal.h
 *
 * Code generation for function 'isequal'
 *
 */

#ifndef ISEQUAL_H
#define ISEQUAL_H

/* Include files */
#include "getCurrentLim_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
boolean_T b_isequal(const emxArray_char_T *varargin_1,
                    const unsigned char varargin_2[6]);

boolean_T c_isequal(const emxArray_char_T *varargin_1,
                    const unsigned char varargin_2[7]);

boolean_T d_isequal(const emxArray_char_T *varargin_1,
                    const unsigned char varargin_2[3]);

boolean_T e_isequal(const emxArray_char_T *varargin_1,
                    const unsigned char varargin_2[8]);

boolean_T isequal(const emxArray_char_T *varargin_1,
                  const unsigned char varargin_2[5]);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (isequal.h) */
