/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getCurrentLim.h
 *
 * Code generation for function 'getCurrentLim'
 *
 */

#ifndef GETCURRENTLIM_H
#define GETCURRENTLIM_H

/* Include files */
#include "getCurrentLim_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern double getCurrentLim(const struct0_T *fisData, double temp_cell,
                            double rpm_mot, double energy_margin);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (getCurrentLim.h) */
