/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * isequal.c
 *
 * Code generation for function 'isequal'
 *
 */

/* Include files */
#include "isequal.h"
#include "getCurrentLim_types.h"
#include "rt_nonfinite.h"

/* Function Definitions */
boolean_T b_isequal(const emxArray_char_T *varargin_1,
                    const unsigned char varargin_2[6])
{
  int k;
  const char *varargin_1_data;
  boolean_T exitg1;
  boolean_T p;
  varargin_1_data = varargin_1->data;
  p = (varargin_1->size[1] == 6);
  if (p && (varargin_1->size[1] != 0)) {
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k < 6)) {
      if ((unsigned char)varargin_1_data[k] != varargin_2[k]) {
        p = false;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }
  return p;
}

boolean_T c_isequal(const emxArray_char_T *varargin_1,
                    const unsigned char varargin_2[7])
{
  int k;
  const char *varargin_1_data;
  boolean_T exitg1;
  boolean_T p;
  varargin_1_data = varargin_1->data;
  p = (varargin_1->size[1] == 7);
  if (p && (varargin_1->size[1] != 0)) {
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k < 7)) {
      if ((unsigned char)varargin_1_data[k] != varargin_2[k]) {
        p = false;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }
  return p;
}

boolean_T d_isequal(const emxArray_char_T *varargin_1,
                    const unsigned char varargin_2[3])
{
  int k;
  const char *varargin_1_data;
  boolean_T exitg1;
  boolean_T p;
  varargin_1_data = varargin_1->data;
  p = (varargin_1->size[1] == 3);
  if (p && (varargin_1->size[1] != 0)) {
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k < 3)) {
      if ((unsigned char)varargin_1_data[k] != varargin_2[k]) {
        p = false;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }
  return p;
}

boolean_T e_isequal(const emxArray_char_T *varargin_1,
                    const unsigned char varargin_2[8])
{
  int k;
  const char *varargin_1_data;
  boolean_T exitg1;
  boolean_T p;
  varargin_1_data = varargin_1->data;
  p = (varargin_1->size[1] == 8);
  if (p && (varargin_1->size[1] != 0)) {
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k < 8)) {
      if ((unsigned char)varargin_1_data[k] != varargin_2[k]) {
        p = false;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }
  return p;
}

boolean_T isequal(const emxArray_char_T *varargin_1,
                  const unsigned char varargin_2[5])
{
  int k;
  const char *varargin_1_data;
  boolean_T exitg1;
  boolean_T p;
  varargin_1_data = varargin_1->data;
  p = (varargin_1->size[1] == 5);
  if (p && (varargin_1->size[1] != 0)) {
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k < 5)) {
      if ((unsigned char)varargin_1_data[k] != varargin_2[k]) {
        p = false;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }
  return p;
}

/* End of code generation (isequal.c) */
